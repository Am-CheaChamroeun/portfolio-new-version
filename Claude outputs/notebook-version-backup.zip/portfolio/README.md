# Portfolio

Personal portfolio built with **Vite + React + TypeScript + Tailwind CSS v4**, animated with **Motion** and icons from **Lucide** / **simple-icons**.

Concept: **"The Developer's Notebook — From Sketch to Software."** A futuristic dark notebook: graphite drafting desk, notebook pages, pencil sketches and handwritten notes, with neon-yellow highlights. Graphite (dark) is the default theme; Warm Paper (light) is one click away.

## Run it

```bash
npm install
npm run dev       # http://localhost:5173
npm run build     # type-check + production build → dist/
npm run preview   # serve the production build
```

## Languages

The site is available in **English** (default), **Khmer** and **Simplified Chinese**. Visitors switch with the globe menu in the navbar; the choice is saved in `localStorage` (`notebook-lang`) and restored on the next visit. English is used on a first visit — the browser language is never auto-detected.

- Setup: `src/i18n/index.ts` (react-i18next). It keeps `<html lang>`, the page title and the meta description in sync with the language.
- Text: `src/i18n/locales/en.json`, `km.json`, `zh-CN.json`. All three must have the same keys — English is the reference, and TypeScript checks keys against it.
- Fonts: Noto Sans Khmer and Noto Sans SC are added automatically for Khmer/Chinese characters (see the `html[lang=…]` rules in `styles/index.css`).

## Make it yours

Your content lives in two places:

| What | Where |
| --- | --- |
| Name, links, photo, CV, tech names, skill levels, project names, certificate titles | `src/data/portfolio.ts` (same in every language) |
| Every sentence a visitor reads — bio, tagline, descriptions, highlights, labels | the `content` section of each file in `src/i18n/locales/` |

Items are matched by id: e.g. the education entry with `id: 'edu-1'` takes its text from `content.education.edu-1` in each locale file; projects use their `slug`, services their `id`.

| Also | Where |
| --- | --- |
| Photo / avatar | put `profile.jpg` in `public/`, set `profile.photo: '/profile.jpg'` |
| CV download | put `cv.pdf` in `public/` (or set `profile.cvUrl: ''` to hide the buttons) |
| Globe marker | `profile.globeMarker: [lat, lng]` |
| Contact form | set `contactFormEndpoint` (e.g. Formspree) — otherwise it opens the visitor's email app |

Tech logos come from [simple-icons](https://simpleicons.org). To use a new one, add it to `src/lib/tech.ts`, then reference its key in the data file.

## Images (temporary mocks)

Until you add real images, the site uses original SVG illustrations in `src/assets/mock/`, listed in **`src/data/images.ts`**. Mock project previews and certificates carry a translated "Concept preview" / "Sample preview" label, so they're never mistaken for real work.

| Mock | Replace it by setting… |
| --- | --- |
| Journal-page portrait (`profile/portrait-sketch.svg`) | `profile.photo` in `portfolio.ts` |
| Project previews (`projects/*.svg`, 16:9) | each project's `image` |
| Certificate layouts (`certifications/*.svg`, 7:5) | each certificate's `image` |
| Education emblems (`education/emblem-*.svg`) | each education item's `logo` |
| Decorative art — hero desk, specialization drawings, contact envelope, books, ruler | the import path in `src/data/images.ts` |

A real image always wins over the mock, so no component changes are needed. Put real files in `public/` (WebP or AVIF recommended) and reference them by path, e.g. `'/projects/shop.webp'`.

## Structure

```text
src/
├── App.tsx                 page composition
├── data/portfolio.ts       ← names, links, images (language-independent)
├── data/images.ts          ← temporary mock images + how to replace them
├── assets/mock/            original SVG placeholder art, by section
├── i18n/                   language setup + locales/{en,km,zh-CN}.json ← all text
├── sections/               Hero, About, Education, Skills, Certifications,
│   └── hero/               Projects, Services, Stats, Contact (+ journal card,
│                           field notes, blueprint sheet)
├── components/
│   ├── layout/             Header, LanguageSwitcher, Footer, Preloader
│   ├── effects/            Globe, SketchToSoftware, PencilCursor, ScrollPencil,
│   │                       ScrollProgress, BackToTop
│   └── ui/                 Reveal, SectionHeading, InkUnderline, Pencil,
│                           StatusPill, Avatar
├── hooks/                  useTheme, useIsDark, useInterval
├── lib/                    icon helpers, shared easing
└── styles/index.css        colour tokens (graphite + warm paper), paper/grid/ruled utilities
```

Fonts: Fraunces (editorial serif), Caveat (handwritten notes), Geist (body), JetBrains Mono (labels), plus Noto Sans Khmer / Noto Sans SC for Khmer and Chinese.

## Notes

- Graphite (dark) is the default; the moon/sun button switches to Warm Paper (light) with a circular reveal and remembers the choice.

## Colours

Every colour comes from the tokens at the top of `src/styles/index.css` — change them there, not in components.

| Token | Value | Used for |
| --- | --- | --- |
| Primary background (`graphite`) | `#0B0D0F` | page background, hero, footer |
| Secondary background (`graphite-2`) | `#191C20` | cards, notebook pages |
| Neon yellow (`neon`) | `#EFFF00` | buttons, active links, highlights, icons, progress, pencil strokes |
| Golden yellow (`gold`) | `#FFD600` | hover states, secondary accents |
| Warm white (`warm`) | `#F5F5E9` | main text on dark |
| Muted grey (`steel`) | `#A8ADB5` | secondary text |
| Border grey (`edge`) | `#34383E` | borders, dividers |

Components use the semantic names (`bg-bg`, `bg-sheet`, `text-fg`, `text-muted`, `text-primary`, `bg-cta`/`text-on-cta` for filled buttons, `stroke-accent` for pencil lines), which switch between the dark and light themes. The fixed names (`bg-graphite`, `text-neon`, …) are only used on surfaces that stay dark in both themes.
- Animations respect `prefers-reduced-motion`. The pencil cursor only appears with a mouse.
