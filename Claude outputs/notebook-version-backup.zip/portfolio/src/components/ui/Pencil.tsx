import { useId } from 'react'

/**
 * Hexagonal drafting pencil, tip pointing down. Viewbox 0 0 24 160 — the
 * graphite point sits at (12, 160), which is handy for cursor alignment.
 */
export function Pencil({ className = '' }: { className?: string }) {
  const id = useId().replace(/:/g, '')
  return (
    <svg viewBox="0 0 24 160" className={className} aria-hidden="true">
      <defs>
        <linearGradient id={`${id}-body`} x1="0" x2="1">
          <stop offset="0%" stopColor="#b8a400" />
          <stop offset="38%" stopColor="#efff00" />
          <stop offset="62%" stopColor="#ffd600" />
          <stop offset="100%" stopColor="#c9a800" />
        </linearGradient>
        <linearGradient id={`${id}-metal`} x1="0" x2="1">
          <stop offset="0%" stopColor="#4a4f57" />
          <stop offset="50%" stopColor="#f5f5e9" />
          <stop offset="100%" stopColor="#34383e" />
        </linearGradient>
        <linearGradient id={`${id}-wood`} x1="0" x2="1">
          <stop offset="0%" stopColor="#d9b98a" />
          <stop offset="55%" stopColor="#f3dfbd" />
          <stop offset="100%" stopColor="#caa673" />
        </linearGradient>
      </defs>
      {/* eraser */}
      <rect x="3" y="0" width="18" height="16" rx="4" fill="#191c20" />
      <rect x="3" y="10" width="18" height="6" fill="#34383e" />
      {/* ferrule */}
      <rect x="2.5" y="15" width="19" height="13" fill={`url(#${id}-metal)`} />
      <path d="M2.5 19.5h19M2.5 23.5h19" stroke="#191c20" strokeWidth="0.8" />
      {/* body */}
      <rect x="3" y="28" width="18" height="96" fill={`url(#${id}-body)`} />
      <path d="M9 28v96M15 28v96" stroke="#0b0d0f" strokeOpacity="0.2" strokeWidth="0.8" />
      <text x="12" y="76" fill="#0b0d0f" fontSize="6" fontFamily="monospace" textAnchor="middle" transform="rotate(90 12 76)" opacity="0.7">
        HB · NOTEBOOK
      </text>
      {/* sharpened wood */}
      <path d="M3 124 L21 124 L14.2 150 L9.8 150 Z" fill={`url(#${id}-wood)`} />
      <path d="M3 124 q3 3 6 0 q3 3 6 0 q3 3 6 0" fill="none" stroke="#8a7a00" strokeWidth="1.2" />
      {/* graphite */}
      <path d="M9.8 150 L14.2 150 L12 160 Z" fill="#0b0d0f" />
    </svg>
  )
}
