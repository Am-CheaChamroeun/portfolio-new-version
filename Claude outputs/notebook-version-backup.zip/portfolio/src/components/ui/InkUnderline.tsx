import { motion, useAnimationControls } from 'motion/react'
import { useEffect, type ReactNode } from 'react'

type Variant = 'underline' | 'circle' | 'double'

const paths: Record<Variant, { viewBox: string; d: string[] }> = {
  underline: { viewBox: '0 0 200 20', d: ['M3 13 C 45 6, 95 16, 140 9 S 190 7, 197 10'] },
  double: {
    viewBox: '0 0 200 24',
    d: ['M3 10 C 50 4, 120 14, 197 7', 'M12 19 C 70 13, 130 21, 190 15'],
  },
  circle: {
    viewBox: '0 0 220 90',
    d: ['M120 6 C 60 2, 10 18, 8 44 C 6 72, 70 86, 128 82 C 186 78, 214 58, 210 36 C 206 14, 160 4, 96 10'],
  },
}

type Props = {
  children: ReactNode
  variant?: Variant
  /** play once on mount (when true) — always replays on hover */
  start?: boolean
  delay?: number
  className?: string
  strokeClassName?: string
}

/**
 * Wraps a word and draws a hand-inked underline or circle around it,
 * like a pencil annotation. Replays when hovered.
 */
export function InkUnderline({
  children,
  variant = 'underline',
  start = true,
  delay = 0,
  className = '',
  strokeClassName = 'stroke-accent',
}: Props) {
  const controls = useAnimationControls()
  const shape = paths[variant]

  const play = (d = 0) =>
    controls.start((i: number) => ({
      pathLength: [0, 1],
      opacity: [1, 1],
      transition: { duration: variant === 'circle' ? 0.9 : 0.6, delay: d + i * 0.25, ease: 'easeInOut' },
    }))

  useEffect(() => {
    if (start) play(delay)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [start])

  const isCircle = variant === 'circle'
  return (
    <span className={`relative inline-block whitespace-nowrap ${className}`} onMouseEnter={() => play()}>
      <span className="relative z-10">{children}</span>
      <svg
        viewBox={shape.viewBox}
        preserveAspectRatio="none"
        aria-hidden="true"
        className={`pointer-events-none absolute ${
          isCircle ? '-inset-x-[12%] -inset-y-[18%] h-[136%] w-[124%]' : '-bottom-[0.18em] left-0 h-[0.32em] w-full'
        }`}
        fill="none"
      >
        {shape.d.map((d, i) => (
          <motion.path
            key={i}
            custom={i}
            d={d}
            initial={{ pathLength: 0, opacity: 0 }}
            animate={controls}
            className={strokeClassName}
            strokeWidth={isCircle ? 3 : 4}
            strokeLinecap="round"
            vectorEffect="non-scaling-stroke"
          />
        ))}
      </svg>
    </span>
  )
}
