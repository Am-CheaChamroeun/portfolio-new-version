import { motion, useMotionValue, useSpring } from 'motion/react'
import { useEffect, useState } from 'react'
import { Pencil } from '../ui/Pencil'

/**
 * Replaces the mouse pointer with a drafting pencil whose graphite tip is the
 * hotspot. It leans with horizontal movement and presses down on click.
 */
export function PencilCursor() {
  const [enabled, setEnabled] = useState(false)
  const [visible, setVisible] = useState(false)
  const [pressed, setPressed] = useState(false)
  const x = useMotionValue(-100)
  const y = useMotionValue(-100)
  const lean = useMotionValue(28)
  const rotate = useSpring(lean, { stiffness: 220, damping: 18 })

  useEffect(() => {
    const fine = window.matchMedia('(pointer: fine)')
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)')
    const update = () => setEnabled(fine.matches && !reduce.matches)
    update()
    fine.addEventListener('change', update)
    reduce.addEventListener('change', update)
    return () => {
      fine.removeEventListener('change', update)
      reduce.removeEventListener('change', update)
    }
  }, [])

  useEffect(() => {
    const root = document.documentElement
    if (!enabled) {
      root.classList.remove('cursor-pencil-active')
      return
    }
    root.classList.add('cursor-pencil-active')
    let lastX = 0
    let settle = 0
    const move = (e: PointerEvent) => {
      const dx = e.clientX - lastX
      lastX = e.clientX
      lean.set(28 + Math.max(-14, Math.min(14, dx * 1.2)))
      clearTimeout(settle)
      settle = window.setTimeout(() => lean.set(28), 120)
      x.set(e.clientX)
      y.set(e.clientY)
      setVisible(true)
    }
    const leave = () => setVisible(false)
    const down = () => setPressed(true)
    const up = () => setPressed(false)
    window.addEventListener('pointermove', move)
    document.addEventListener('pointerleave', leave)
    window.addEventListener('pointerdown', down)
    window.addEventListener('pointerup', up)
    return () => {
      clearTimeout(settle)
      root.classList.remove('cursor-pencil-active')
      window.removeEventListener('pointermove', move)
      document.removeEventListener('pointerleave', leave)
      window.removeEventListener('pointerdown', down)
      window.removeEventListener('pointerup', up)
    }
  }, [enabled, lean, x, y])

  if (!enabled) return null

  return (
    <motion.div
      aria-hidden="true"
      className="pointer-events-none fixed left-0 top-0 z-[9999] will-change-transform"
      style={{ x, y, opacity: visible ? 1 : 0 }}
    >
      {/* rotate around the graphite tip, which sits at the bottom-centre of the pencil */}
      <motion.div
        className="absolute bottom-0 left-0 h-14 w-[9px] origin-bottom -translate-x-1/2"
        style={{ rotate }}
        animate={{ scale: pressed ? 0.88 : 1 }}
      >
        <Pencil className="h-full w-full drop-shadow-[2px_4px_6px_rgba(0,0,0,0.45)]" />
      </motion.div>
    </motion.div>
  )
}
