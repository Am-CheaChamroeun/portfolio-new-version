import { motion } from 'motion/react'
import { useTranslation } from 'react-i18next'

const stroke = { strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const, fill: 'none' }

/** A pencil wireframe that draws itself, line by line. */
export function WireframeSketch({ start, className = '' }: { start: boolean; className?: string }) {
  const { t } = useTranslation()
  const lines = [
    // browser frame (slightly wobbly, hand drawn)
    'M8 10 C 60 8, 120 11, 172 9 C 173 50, 171 100, 172 130 C 120 132, 60 129, 9 131 C 7 90, 9 50, 8 10 Z',
    'M8 26 C 60 25, 120 27, 172 25',
    // window dots
    'M18 18 a2 2 0 1 0 0.1 0 M27 18 a2 2 0 1 0 0.1 0 M36 18 a2 2 0 1 0 0.1 0',
    // image placeholder with cross
    'M20 38 L 92 37 L 93 84 L 21 85 Z',
    'M21 38 L 92 84 M92 38 L 21 84',
    // text lines
    'M104 40 C 130 39, 150 41, 160 40',
    'M104 52 C 125 51, 140 53, 152 52',
    'M104 64 C 120 63, 135 65, 146 64',
    // button
    'M104 76 C 125 75, 140 77, 150 76 C 151 81, 150 85, 150 88 C 135 89, 118 87, 104 88 C 103 84, 104 80, 104 76 Z',
    // footer cards
    'M20 98 L 62 97 L 63 120 L 21 121 Z',
    'M72 98 L 114 98 L 113 120 L 72 121 Z',
    'M124 97 L 162 98 L 161 121 L 124 120 Z',
  ]
  return (
    <svg viewBox="0 0 180 140" className={className} aria-hidden="true">
      {lines.map((d, i) => (
        <motion.path
          key={i}
          d={d}
          {...stroke}
          className="stroke-faint"
          strokeWidth={1.4}
          initial={{ pathLength: 0, opacity: 0 }}
          animate={start ? { pathLength: 1, opacity: 1 } : undefined}
          transition={{ duration: 0.55, delay: 0.6 + i * 0.16, ease: 'easeInOut' }}
        />
      ))}
      <motion.text
        x="90"
        y="139"
        textAnchor="middle"
        className="fill-faint font-hand"
        fontSize="13"
        initial={{ opacity: 0 }}
        animate={start ? { opacity: 1 } : undefined}
        transition={{ delay: 2.6 }}
      >
        {t('hero.fig1')}
      </motion.text>
    </svg>
  )
}

/** The same layout, "shipped": a clean UI card. */
export function RenderedCard({ start, className = '' }: { start: boolean; className?: string }) {
  const { t } = useTranslation()
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 14, rotate: 2 }}
      animate={start ? { opacity: 1, y: 0, rotate: 1.5 } : undefined}
      transition={{ duration: 0.7, delay: 2.9, ease: [0.22, 1, 0.36, 1] }}
      aria-hidden="true"
    >
      <div className="overflow-hidden rounded-lg border border-card-border bg-bg-elevated shadow-paper">
        <div className="flex items-center gap-1 border-b border-card-border bg-bg-subtle px-2 py-1.5">
          <span className="h-1.5 w-1.5 rounded-full bg-accent/80" />
          <span className="h-1.5 w-1.5 rounded-full bg-accent/50" />
          <span className="h-1.5 w-1.5 rounded-full bg-accent/25" />
        </div>
        <div className="grid grid-cols-[1.1fr_1fr] gap-2 p-2.5">
          <div className="aspect-[4/3] rounded bg-gradient-to-br from-bg-subtle to-accent/30 dark:from-edge dark:to-neon/25" />
          <div className="space-y-1.5 pt-0.5">
            <div className="h-1.5 w-full rounded bg-fg/70" />
            <div className="h-1.5 w-4/5 rounded bg-fg/25" />
            <div className="h-1.5 w-3/5 rounded bg-fg/25" />
            <div className="mt-2 h-3.5 w-1/2 rounded bg-cta" />
          </div>
        </div>
        <div className="grid grid-cols-3 gap-1.5 px-2.5 pb-2.5">
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-5 rounded border border-card-border bg-bg-subtle" />
          ))}
        </div>
      </div>
      <p className="mt-2 text-center font-hand text-[13px] text-faint">{t('hero.fig2')}</p>
    </motion.div>
  )
}

/** Deterministic scattering of ink dots, for the hero's drafting-grid background. */
export function InkDots({ className = '' }: { className?: string }) {
  const dots = Array.from({ length: 46 }, (_, i) => {
    const a = (i * 137.508 * Math.PI) / 180
    const r = 30 + ((i * 53) % 70)
    return { x: 50 + Math.cos(a) * r * 0.62, y: 50 + Math.sin(a) * r * 0.48, s: (i % 4) * 0.25 + 0.35 }
  })
  return (
    <svg viewBox="0 0 100 100" preserveAspectRatio="none" className={className} aria-hidden="true">
      {dots.map((d, i) => (
        <circle key={i} cx={d.x} cy={d.y} r={d.s * 0.18} className="fill-warm" opacity={0.18 + (i % 5) * 0.06} />
      ))}
    </svg>
  )
}
