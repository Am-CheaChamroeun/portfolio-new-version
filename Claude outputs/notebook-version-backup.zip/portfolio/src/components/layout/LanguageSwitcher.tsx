import { Check, ChevronDown, Globe } from 'lucide-react'
import { AnimatePresence, motion } from 'motion/react'
import { useEffect, useId, useRef, useState, type KeyboardEvent } from 'react'
import { useTranslation } from 'react-i18next'
import { languages, type LanguageCode } from '../../i18n'

type Props = {
  /** true while the header is over the dark graphite hero (light-on-dark styling) */
  onDark: boolean
}

/**
 * Globe button + dropdown for EN / ខ្មែរ / 中文.
 * Keyboard: Enter/Space/↓ opens, ↑/↓/Home/End move, Enter/Space selects,
 * Escape closes and returns focus, Tab closes. Outside clicks close it too.
 */
export function LanguageSwitcher({ onDark }: Props) {
  const { t, i18n } = useTranslation()
  const [open, setOpen] = useState(false)
  const [focusIndex, setFocusIndex] = useState(0)
  const rootRef = useRef<HTMLDivElement>(null)
  const buttonRef = useRef<HTMLButtonElement>(null)
  const itemRefs = useRef<(HTMLButtonElement | null)[]>([])
  const menuId = useId()

  const currentIndex = Math.max(
    0,
    languages.findIndex((l) => l.code === i18n.language),
  )
  const current = languages[currentIndex]

  // close on outside click
  useEffect(() => {
    if (!open) return
    const onPointer = (e: PointerEvent) => {
      if (!rootRef.current?.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('pointerdown', onPointer)
    return () => document.removeEventListener('pointerdown', onPointer)
  }, [open])

  // move focus to the highlighted option while open
  useEffect(() => {
    if (open) itemRefs.current[focusIndex]?.focus()
  }, [open, focusIndex])

  const openMenu = (index = currentIndex) => {
    setFocusIndex(index)
    setOpen(true)
  }

  const close = (returnFocus = true) => {
    setOpen(false)
    if (returnFocus) buttonRef.current?.focus()
  }

  const select = (code: LanguageCode) => {
    if (code !== i18n.language) i18n.changeLanguage(code)
    close()
  }

  const onButtonKey = (e: KeyboardEvent<HTMLButtonElement>) => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault()
      openMenu(e.key === 'ArrowUp' ? languages.length - 1 : currentIndex)
    }
  }

  const onMenuKey = (e: KeyboardEvent<HTMLDivElement>) => {
    const last = languages.length - 1
    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault()
        setFocusIndex((i) => (i >= last ? 0 : i + 1))
        break
      case 'ArrowUp':
        e.preventDefault()
        setFocusIndex((i) => (i <= 0 ? last : i - 1))
        break
      case 'Home':
        e.preventDefault()
        setFocusIndex(0)
        break
      case 'End':
        e.preventDefault()
        setFocusIndex(last)
        break
      case 'Escape':
        e.preventDefault()
        close()
        break
      case 'Tab':
        close(false)
        break
    }
  }

  return (
    <div ref={rootRef} className="relative">
      <button
        ref={buttonRef}
        type="button"
        onClick={() => (open ? close() : openMenu())}
        onKeyDown={onButtonKey}
        aria-haspopup="menu"
        aria-expanded={open}
        aria-controls={menuId}
        aria-label={t('language.choose', { language: current.name })}
        className={`group flex h-9 items-center gap-1.5 rounded-full border px-2.5 text-sm transition-colors ${
          onDark
            ? 'border-warm/25 text-warm hover:border-neon/70 hover:bg-neon/10 hover:text-neon'
            : 'border-card-border bg-sheet text-fg hover:border-primary hover:text-primary'
        } ${open ? (onDark ? 'border-neon/70 bg-neon/10 text-neon' : 'border-primary text-primary') : ''}`}
      >
        <Globe size={16} strokeWidth={1.7} className="shrink-0 transition-transform duration-500 group-hover:rotate-[20deg]" />
        <span lang={current.code} className="min-w-[1.6rem] text-center text-[13px] font-medium leading-none">
          {current.short}
        </span>
        <ChevronDown size={14} className={`shrink-0 opacity-70 transition-transform duration-300 ${open ? 'rotate-180' : ''}`} />
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            id={menuId}
            role="menu"
            aria-label={t('language.menu')}
            onKeyDown={onMenuKey}
            initial={{ opacity: 0, y: -6, rotateX: -12, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, rotateX: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, rotateX: -10, scale: 0.98 }}
            transition={{ duration: 0.18, ease: [0.22, 1, 0.36, 1] }}
            style={{ transformPerspective: 800, transformOrigin: 'top right' }}
            className="lined absolute right-0 top-full z-50 mt-2 w-48 overflow-hidden rounded-lg border border-card-border bg-sheet p-1.5 text-fg shadow-paper [--line:2.75rem]"
          >
            <p className="px-2.5 pb-1 pt-1 font-hand text-lg leading-none text-faint">{t('language.label')}</p>
            {languages.map((lang, i) => {
              const active = lang.code === current.code
              return (
                <button
                  key={lang.code}
                  ref={(el) => {
                    itemRefs.current[i] = el
                  }}
                  type="button"
                  role="menuitemradio"
                  aria-checked={active}
                  lang={lang.code}
                  tabIndex={i === focusIndex ? 0 : -1}
                  onClick={() => select(lang.code)}
                  onMouseEnter={() => setFocusIndex(i)}
                  className={`flex w-full items-center gap-3 rounded-md px-2.5 py-2 text-left text-sm transition-colors focus:outline-none ${
                    active ? 'bg-cta text-on-cta' : 'text-muted hover:bg-glow hover:text-primary focus-visible:bg-glow focus-visible:text-primary'
                  }`}
                >
                  <span
                    className={`flex h-6 min-w-9 items-center justify-center rounded border px-1 text-[11px] font-medium ${
                      active ? 'border-on-cta/40' : 'border-card-border'
                    }`}
                  >
                    {lang.short}
                  </span>
                  <span className="flex-1">{lang.name}</span>
                  {active && <Check size={15} className="shrink-0" />}
                </button>
              )
            })}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
