import { Menu, Moon, Sun, X } from 'lucide-react'
import { AnimatePresence, motion, useMotionValueEvent, useScroll } from 'motion/react'
import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { navLinks, profile } from '../../data/portfolio'
import { useTheme } from '../../hooks/useTheme'
import { Avatar } from '../ui/Avatar'
import { LanguageSwitcher } from './LanguageSwitcher'

/** Hand-drawn underline that sketches in on hover. */
function NavUnderline() {
  return (
    <svg
      viewBox="0 0 100 8"
      preserveAspectRatio="none"
      className="pointer-events-none absolute inset-x-3 -bottom-0.5 h-1.5 w-[calc(100%-1.5rem)]"
      aria-hidden="true"
    >
      <path
        d="M2 5 C 25 2, 55 7, 98 3"
        pathLength={1}
        className="stroke-accent [stroke-dasharray:1] [stroke-dashoffset:1] transition-[stroke-dashoffset] duration-500 ease-out group-hover:[stroke-dashoffset:0] group-focus-visible:[stroke-dashoffset:0]"
        strokeWidth="2"
        strokeLinecap="round"
        fill="none"
        vectorEffect="non-scaling-stroke"
      />
    </svg>
  )
}

export function Header() {
  const { scrollY } = useScroll()
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)
  const { theme, toggle } = useTheme()
  const { t } = useTranslation()
  useMotionValueEvent(scrollY, 'change', (v) => setScrolled(v > 20))
  const solid = scrolled || open

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        solid ? 'glass border-b border-line py-3 text-fg' : 'bg-transparent py-5 text-warm'
      }`}
    >
      <nav aria-label={t('nav.mainNavigation')} className="mx-auto flex max-w-6xl items-center justify-between px-5">
        <a href="#home" className="group flex items-center gap-3">
          <span className="relative flex h-9 w-9 rounded-full ring-1 ring-current/30 ring-offset-2 ring-offset-transparent transition-transform group-hover:-rotate-6">
            <Avatar className="h-9 w-9" />
          </span>
          <span className="hidden leading-none sm:block">
            <span className="block font-display text-lg font-medium tracking-tight">
              {profile.handle}
              <span className={solid ? 'text-primary' : 'text-neon'}>{profile.handleSuffix}</span>
            </span>
            <span className={`block font-hand text-[15px] ${solid ? 'text-faint' : 'text-steel'}`}>{t('nav.tagline')}</span>
          </span>
        </a>

        <div className="hidden items-center md:flex">
          {navLinks.map((link, i) => (
            <a
              key={link.href}
              href={link.href}
              className={`group relative whitespace-nowrap px-2.5 py-2 text-sm transition-colors lg:px-3 ${
                solid ? 'text-muted hover:text-fg' : 'text-warm/80 hover:text-neon'
              }`}
            >
              <span className={`mr-1 hidden font-mono text-[10px] lg:inline ${solid ? 'text-faint' : 'text-steel/70'}`}>
                {String(i + 1).padStart(2, '0')}
              </span>
              {t(`nav.${link.key}`)}
              <NavUnderline />
            </a>
          ))}
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          <LanguageSwitcher onDark={!solid} />
          <button
            type="button"
            onClick={(e) => toggle(e)}
            className="flex h-9 w-9 items-center justify-center rounded-full transition-transform hover:rotate-12"
            aria-label={theme === 'dark' ? t('nav.toLight') : t('nav.toDark')}
          >
            {theme === 'dark' ? <Sun size={19} /> : <Moon size={19} />}
          </button>
          <a
            href="#contact"
            className={`hidden whitespace-nowrap rounded-full px-4 py-2 text-sm font-medium transition-all hover:-translate-y-0.5 lg:inline-block ${
              solid ? 'bg-cta text-on-cta hover:bg-cta-hover dark:hover:shadow-neon-sm' : 'bg-neon text-graphite shadow-neon-sm hover:bg-gold'
            }`}
          >
            {t('nav.letsTalk')}
          </a>
          <button
            type="button"
            aria-label={t('nav.toggleMenu')}
            aria-expanded={open}
            onClick={() => setOpen((o) => !o)}
            className={`flex h-9 w-9 items-center justify-center rounded-full border md:hidden ${
              solid ? 'border-card-border bg-sheet text-fg hover:border-primary hover:text-primary' : 'border-warm/30 text-warm hover:border-neon hover:text-neon'
            }`}
          >
            {open ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </nav>

      <AnimatePresence>
        {open && (
          <motion.div
            className="overflow-hidden md:hidden"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
          >
            <div className="ruled mx-5 mt-4 flex flex-col rounded-xl border border-card-border bg-sheet p-3 pl-12 shadow-paper [--line:3rem] [--margin:2.5rem]">
              {navLinks.map((link, i) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className="flex h-12 items-center gap-3 text-sm text-muted transition-colors hover:text-primary"
                >
                  <span className="font-mono text-[10px] text-faint">{String(i + 1).padStart(2, '0')}</span>
                  {t(`nav.${link.key}`)}
                </a>
              ))}
              <a
                href="#contact"
                onClick={() => setOpen(false)}
                className="mt-2 rounded-full bg-cta px-4 py-3 text-center text-sm font-medium text-on-cta hover:bg-cta-hover"
              >
                {t('nav.letsTalk')}
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  )
}
