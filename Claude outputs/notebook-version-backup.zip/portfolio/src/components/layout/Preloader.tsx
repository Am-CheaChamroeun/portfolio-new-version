import { AnimatePresence, motion } from 'motion/react'
import { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { preloader, profile } from '../../data/portfolio'
import { Avatar } from '../ui/Avatar'
import { Pencil } from '../ui/Pencil'

/** Progress thresholds for each status line (labels: preloader.steps in the locale files) */
const stepThresholds = [36, 60, 86, 100]

/** Notebook-opening loader: the cover swings open, a pencil writes the progress line. */
export function Preloader({ onDone }: { onDone: () => void }) {
  const [progress, setProgress] = useState(0)
  const [visible, setVisible] = useState(true)
  const { t } = useTranslation()
  const stepLabels = t('preloader.steps', { returnObjects: true })

  useEffect(() => {
    document.documentElement.style.overflow = 'hidden'
    const tick = setInterval(() => {
      setProgress((p) => {
        const next = Math.min(100, p + 7 + Math.random() * 3)
        if (next >= 100) clearInterval(tick)
        return next
      })
    }, 250)
    return () => clearInterval(tick)
  }, [])

  useEffect(() => {
    if (progress < 100) return
    const hold = setTimeout(() => setVisible(false), 1100)
    return () => clearTimeout(hold)
  }, [progress])

  const done = progress >= 100
  const stepIndex = stepThresholds.findIndex((until) => progress < until)
  const status = done ? t('preloader.done') : stepLabels[Math.max(0, stepIndex)]

  return (
    <AnimatePresence
      onExitComplete={() => {
        document.documentElement.style.overflow = ''
        onDone()
      }}
    >
      {visible && (
        <motion.div
          key="preloader"
          className="grid-bg fixed inset-0 z-[9999] flex items-center justify-center overflow-hidden bg-bg"
          exit={{ opacity: 0, scale: 1.04 }}
          transition={{ duration: 0.55, ease: 'easeInOut' }}
          role="status"
          aria-label={t('preloader.loading')}
        >
          <div className="flex flex-col items-center px-6">
            {/* the notebook */}
            <div className="relative h-[330px] w-[250px] sm:h-[360px] sm:w-[280px]" style={{ perspective: 1400 }}>
              {/* first page */}
              <div className="ruled paper-grain absolute inset-0 overflow-hidden rounded-r-xl rounded-l-sm border border-card-border bg-sheet shadow-paper [--line:1.75rem] [--margin:2.25rem]">
                <div className="flex h-full flex-col items-center justify-center px-8 pl-12 text-center">
                  <motion.div
                    initial={{ opacity: 0, scale: 0.6 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 1.1, type: 'spring', stiffness: 220, damping: 18 }}
                  >
                    <Avatar className="h-16 w-16 ring-2 ring-accent/40 ring-offset-2 ring-offset-sheet" />
                  </motion.div>
                  <motion.h2
                    className="mt-4 font-display text-2xl font-medium text-fg"
                    initial={{ clipPath: 'inset(0 100% 0 0)' }}
                    animate={{ clipPath: 'inset(0 0% 0 0)' }}
                    transition={{ delay: 1.35, duration: 0.9, ease: 'easeInOut' }}
                  >
                    {profile.name}
                  </motion.h2>
                  <motion.p
                    className="mt-1 font-hand text-lg leading-tight text-muted"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 1.8 }}
                  >
                    {t('content.profile.preloaderRole')}
                  </motion.p>

                  {/* progress, written in pencil */}
                  <div className="mt-6 w-full">
                    <div className="mb-1.5 flex justify-between font-mono text-[10px] uppercase tracking-wider text-faint">
                      <span>{t('preloader.progress')}</span>
                      <span>{Math.round(progress)}%</span>
                    </div>
                    <div className="relative h-3">
                      <svg viewBox="0 0 100 6" preserveAspectRatio="none" className="absolute inset-0 h-full w-full" aria-hidden="true">
                        <path d="M1 3 Q 25 1.5 50 3 T 99 3" className="stroke-line" strokeWidth="1.2" fill="none" vectorEffect="non-scaling-stroke" />
                        <motion.path
                          d="M1 3 Q 25 1.5 50 3 T 99 3"
                          className="stroke-primary"
                          strokeWidth="2.4"
                          strokeLinecap="round"
                          fill="none"
                          vectorEffect="non-scaling-stroke"
                          animate={{ pathLength: progress / 100 }}
                          transition={{ duration: 0.25, ease: 'linear' }}
                        />
                      </svg>
                      <motion.div
                        className="absolute -top-[46px] h-12 w-[7px] origin-bottom rotate-[22deg]"
                        animate={{ left: `${progress}%` }}
                        transition={{ duration: 0.25, ease: 'linear' }}
                      >
                        <Pencil className="animate-scribble h-full w-full" />
                      </motion.div>
                    </div>
                  </div>
                </div>
              </div>

              {/* cover, swinging open */}
              <motion.div
                className="absolute inset-0 origin-left rounded-r-xl rounded-l-sm bg-gradient-to-br from-graphite-2 to-graphite shadow-2xl ring-1 ring-edge [backface-visibility:hidden]"
                initial={{ rotateY: 0 }}
                animate={{ rotateY: -168 }}
                transition={{ delay: 0.35, duration: 1.25, ease: [0.65, 0, 0.35, 1] }}
                style={{ transformStyle: 'preserve-3d' }}
              >
                <div className="absolute inset-y-0 left-0 w-4 bg-black/20" />
                <div className="absolute inset-4 left-8 rounded border border-neon/30" />
                <div className="flex h-full flex-col items-center justify-center pl-4 text-center">
                  <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-neon/80">{t('preloader.vol')}</span>
                  <span className="mt-3 font-display text-2xl font-medium leading-tight text-warm">
                    {t('preloader.title1')}
                    <br />
                    {t('preloader.title2')}
                  </span>
                  <span className="mt-4 font-hand text-xl text-neon">{profile.name}</span>
                </div>
              </motion.div>
            </div>

            <AnimatePresence mode="wait">
              <motion.p
                key={status}
                className="mt-8 font-hand text-2xl text-primary"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.25 }}
              >
                {status}
              </motion.p>
            </AnimatePresence>
            <motion.div
              className="mt-4 flex flex-wrap justify-center gap-2"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
            >
              {preloader.chips.map((chip) => (
                <span key={chip} className="rounded-sm border border-card-border bg-sheet px-2.5 py-0.5 font-mono text-[11px] text-muted">
                  {chip}
                </span>
              ))}
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
