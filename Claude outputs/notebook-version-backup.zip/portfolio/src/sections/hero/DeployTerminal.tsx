import { useEffect, useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { heroTelemetry, terminalCommands, terminalInfoLines } from '../../data/portfolio'

const TYPE_MS = 35
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))

type Shown = { cmd: string; out?: string; tone?: 'success' | 'info'; typing: boolean }

/** Right hero card: a drafting spec sheet on which the deploy steps are drafted, on a loop. */
export function DeployTerminal({ start }: { start: boolean }) {
  const { t, i18n } = useTranslation()
  // commands stay as written; their output lines come from the locale files
  const terminalLines = useMemo(() => {
    const outputs = t('content.terminal', { returnObjects: true })
    return terminalCommands.map((cmd, i) => ({
      cmd,
      out: outputs[i] || undefined,
      tone: (terminalInfoLines.includes(i) ? 'info' : 'success') as 'info' | 'success',
    }))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [i18n.language])
  const [lines, setLines] = useState<Shown[]>(() => terminalLines.map((l) => ({ ...l, typing: false })))

  useEffect(() => {
    setLines(terminalLines.map((l) => ({ ...l, typing: false }))) // language changed: show the new lines
    if (!start) return
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    let cancelled = false
    const run = async () => {
      await sleep(400)
      while (!cancelled) {
        const shown: Shown[] = []
        for (const line of terminalLines) {
          shown.push({ cmd: '', typing: true })
          for (let i = 1; i <= line.cmd.length && !cancelled; i++) {
            shown[shown.length - 1] = { cmd: line.cmd.slice(0, i), typing: true }
            setLines([...shown])
            await sleep(TYPE_MS)
          }
          await sleep(450)
          shown[shown.length - 1] = { ...line, typing: false }
          setLines([...shown])
          await sleep(line.out ? 900 : 300)
          if (cancelled) return
        }
        await sleep(2600)
      }
    }
    run()
    return () => {
      cancelled = true
    }
  }, [start, terminalLines])

  return (
    <>
      <div className="drafting-grid relative rotate-[1deg] overflow-hidden rounded-md border border-edge font-mono text-[10.5px] leading-relaxed text-warm shadow-[0_24px_50px_-24px_rgba(0,0,0,0.9)]">
        <div className="flex items-center justify-between border-b border-warm/15 px-3 py-1.5">
          <span className="text-[9px] uppercase tracking-[0.22em] text-neon/80">{t('hero.blueprint.title')}</span>
          <span className="inline-flex items-center gap-1 text-[9px] text-steel">
            <span className="h-1 w-1 animate-pulse rounded-full bg-neon" />
            {t('hero.blueprint.drafting')}
          </span>
        </div>
        <div className="min-h-[150px] space-y-1 p-3">
          {lines.map((line, i) => (
            <div key={i}>
              <div className="flex items-start gap-1.5">
                <span className="text-neon/70">{String(i + 1).padStart(2, '0')}</span>
                <span className="break-all text-warm/90">
                  {line.cmd}
                  {line.typing && <span className="cursor-blink">▍</span>}
                </span>
              </div>
              {line.out && (
                <div className={`pl-5 font-hand text-[15px] leading-snug ${line.tone === 'info' ? 'text-neon' : 'text-steel'}`}>{line.out}</div>
              )}
            </div>
          ))}
        </div>
        {/* engineering title block */}
        <div className="grid grid-cols-3 border-t border-warm/15 text-[8px] uppercase tracking-wider text-steel">
          <span className="border-r border-warm/15 px-2 py-1">{t('hero.blueprint.scale')}</span>
          <span className="border-r border-warm/15 px-2 py-1">{t('hero.blueprint.rev')}</span>
          <span className="px-2 py-1">{t('hero.blueprint.sheet')}</span>
        </div>
      </div>
      <div className="mt-4 grid grid-cols-2 gap-2.5">
        {[
          { label: t('hero.blueprint.deploys'), value: heroTelemetry.deploys },
          { label: t('hero.blueprint.uptime'), value: heroTelemetry.uptime },
        ].map((s, i) => (
          <div
            key={s.label}
            className={`rounded-sm border border-card-border bg-sheet px-2.5 py-2 shadow-[0_12px_24px_-16px_rgba(0,0,0,0.85)] ${
              i ? 'rotate-[1.5deg]' : 'rotate-[-1.5deg]'
            }`}
          >
            <div className="font-mono text-[9px] uppercase tracking-wider text-faint">{s.label}</div>
            <div className="mt-0.5 font-display text-lg font-medium text-primary">{s.value}</div>
          </div>
        ))}
      </div>
    </>
  )
}
