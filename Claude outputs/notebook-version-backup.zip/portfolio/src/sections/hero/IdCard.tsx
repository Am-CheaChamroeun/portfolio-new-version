import { motion, useMotionValue, useSpring } from 'motion/react'
import type { PointerEvent } from 'react'
import { useTranslation } from 'react-i18next'
import { mockImages } from '../../data/images'
import { profile } from '../../data/portfolio'

const MAX_TILT = 7
const YEAR = new Date().getFullYear()

// ruler tick marks, laid out once
const ticks = Array.from({ length: 41 }, (_, i) => ({ x: i * 5, h: i % 10 === 0 ? 7 : i % 5 === 0 ? 5 : 3 }))

/** The personal journal page: taped photo, name, signature — tilts in 3D with the pointer. */
export function IdCard() {
  const { t } = useTranslation()
  const rx = useMotionValue(0)
  const ry = useMotionValue(0)
  const rotateX = useSpring(rx, { stiffness: 150, damping: 15 })
  const rotateY = useSpring(ry, { stiffness: 150, damping: 15 })

  const onMove = (e: PointerEvent<HTMLDivElement>) => {
    if (e.pointerType !== 'mouse') return
    const rect = e.currentTarget.getBoundingClientRect()
    const px = (e.clientX - rect.left) / rect.width - 0.5
    const py = (e.clientY - rect.top) / rect.height - 0.5
    ry.set(px * MAX_TILT * 2)
    rx.set(-py * MAX_TILT * 2)
  }
  const reset = () => {
    rx.set(0)
    ry.set(0)
  }

  return (
    <div className="relative" style={{ perspective: 1400 }}>
      <motion.div
        onPointerMove={onMove}
        onPointerLeave={reset}
        style={{ rotateX, rotateY, transformStyle: 'preserve-3d' }}
        className="relative w-[300px]"
      >
        {/* pages peeking out underneath */}
        <div className="absolute inset-0 translate-x-[6px] translate-y-[6px] rounded-r-xl rounded-l-sm bg-edge/80" />
        <div className="absolute inset-0 translate-x-[3px] translate-y-[3px] rounded-r-xl rounded-l-sm bg-steel/20" />

        <div className="lined paper-grain relative overflow-hidden rounded-r-xl rounded-l-sm bg-graphite-2 text-warm ring-1 ring-edge shadow-[0_30px_60px_-20px_rgba(0,0,0,0.85)] [--line:1.5rem] [--rule:rgba(245,245,233,0.07)]">
          {/* spiral binding */}
          <div className="absolute inset-y-3 left-0 flex w-5 flex-col justify-between" aria-hidden="true">
            {Array.from({ length: 14 }, (_, i) => (
              <span key={i} className="relative block h-3.5">
                <span className="absolute left-1.5 top-1/2 h-2 w-2 -translate-y-1/2 rounded-full bg-graphite shadow-inner" />
                <span className="absolute -left-1.5 top-1/2 h-[3px] w-4 -translate-y-1/2 rounded-full bg-gradient-to-r from-steel to-warm" />
              </span>
            ))}
          </div>
          <div className="absolute inset-y-0 left-7 w-px bg-neon/40" />

          <div className="relative py-4 pl-10 pr-4">
            <div className="flex items-start justify-between">
              <div>
                <div className="font-mono text-[8.5px] uppercase tracking-[0.22em] text-neon/80">{t('hero.journal.title', { year: YEAR })}</div>
                <div className="mt-0.5 font-display text-base font-medium tracking-tight text-warm">
                  {profile.handle}
                  <span className="text-neon">{profile.handleSuffix}</span>
                </div>
              </div>
              <span className="font-hand text-lg leading-none text-steel">{t('hero.journal.page')}</span>
            </div>

            {/* taped photo */}
            <div className="relative mt-4 rotate-[-1.5deg]">
              <span className="absolute -top-2.5 left-6 z-10 h-5 w-16 -rotate-6 bg-neon/25 backdrop-blur-[1px]" />
              <span className="absolute -top-2 right-5 z-10 h-5 w-14 rotate-[8deg] bg-gold/25 backdrop-blur-[1px]" />
              <div className="relative aspect-[4/5] overflow-hidden border-[6px] border-warm bg-warm shadow-[0_8px_18px_-8px_rgba(0,0,0,0.6)]">
                {profile.photo ? (
                  <img
                    src={profile.photo}
                    alt={`${profile.name} — ${t('content.profile.role')}`}
                    className="absolute inset-0 h-full w-full object-cover object-top"
                  />
                ) : mockImages.profile ? (
                  <>
                    {/* temporary illustrated portrait — set profile.photo to use your real photo */}
                    <img
                      src={mockImages.profile}
                      alt={t('images.alt.profile')}
                      fetchPriority="high"
                      className="absolute inset-0 h-full w-full object-cover"
                    />
                    <span className="absolute bottom-2 right-2 rotate-[-3deg] rounded-sm bg-graphite/90 px-1.5 font-hand text-sm leading-tight text-neon shadow-sm">
                      {t('hero.journal.photo')}
                    </span>
                  </>
                ) : (
                  <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-b from-graphite-2 to-edge">
                    <svg viewBox="0 0 100 100" className="absolute bottom-0 h-[78%] w-auto text-warm/10" aria-hidden="true">
                      <circle cx="50" cy="34" r="19" fill="currentColor" />
                      <path d="M10 100c2-24 18-38 40-38s38 14 40 38Z" fill="currentColor" />
                    </svg>
                    <span className="relative font-display text-6xl font-medium text-warm/85">{profile.initials}</span>
                    <span className="relative mt-1 font-hand text-base text-neon/80">{t('hero.journal.photo')}</span>
                  </div>
                )}
              </div>
            </div>

            {/* ruler */}
            <svg viewBox="0 0 200 9" className="mt-4 h-2.5 w-full text-neon/45" aria-hidden="true">
              <path d="M0 0.5 H200" stroke="currentColor" />
              {ticks.map((t) => (
                <path key={t.x} d={`M${t.x} 0.5 V${t.h}`} stroke="currentColor" strokeWidth="0.8" />
              ))}
            </svg>

            <div className="pt-2.5">
              <div className="font-display text-xl font-medium leading-tight text-warm">{profile.name}</div>
              <div className="font-hand text-lg leading-tight text-neon">{t('content.profile.badgeRole')}</div>
            </div>
            <div className="mt-2.5 flex items-end gap-3 border-t border-dashed border-warm/15 pt-2">
              <div className="min-w-0 flex-1">
                <div className="font-mono text-[8.5px] uppercase tracking-[0.18em] text-steel/80">{t('hero.journal.entryNo')}</div>
                <div className="mt-0.5 font-mono text-[11px] tracking-wider text-warm">{profile.badgeId}</div>
              </div>
              {/* signature */}
              <svg viewBox="0 0 120 34" className="h-8 w-28 text-neon" fill="none" aria-hidden="true">
                <motion.path
                  d="M4 24 C 12 6, 20 6, 18 22 C 17 30, 26 14, 32 12 C 38 10, 34 26, 42 22 C 48 19, 50 12, 56 14 C 62 16, 58 26, 66 24 C 74 22, 78 12, 86 14 C 92 16, 90 24, 98 22 C 104 20, 110 16, 116 18"
                  stroke="currentColor"
                  strokeWidth="1.6"
                  strokeLinecap="round"
                  initial={{ pathLength: 0 }}
                  whileInView={{ pathLength: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 1.6, delay: 1, ease: 'easeInOut' }}
                />
              </svg>
            </div>
          </div>
        </div>
      </motion.div>
      <div className="pointer-events-none absolute -bottom-6 left-1/2 h-8 w-[80%] -translate-x-1/2 rounded-[50%] bg-black/40 blur-2xl" />
    </div>
  )
}
