import { ArrowRight, BookOpen, Download, Mail } from 'lucide-react'
import { motion, useMotionValue, useSpring } from 'motion/react'
import { useEffect, useState, type PointerEvent, type ReactNode } from 'react'
import { useTranslation } from 'react-i18next'
import { InkDots, RenderedCard, WireframeSketch } from '../components/effects/SketchToSoftware'
import { mockImages } from '../data/images'
import { InkUnderline } from '../components/ui/InkUnderline'
import { profile, socials } from '../data/portfolio'
import { useInterval } from '../hooks/useInterval'
import { formatDate } from '../i18n'
import { easeOut } from '../lib/motion'
import { DeployTerminal } from './hero/DeployTerminal'
import { IdCard } from './hero/IdCard'
import { MissionControl } from './hero/MissionControl'

const pad = (n: number, l = 2) => String(n).padStart(l, '0')
const LOADED_AT = new Date()

/** Entrance animation that waits for the notebook-opening preloader to finish. */
function Enter({
  ready,
  delay = 0,
  y = 20,
  x = 0,
  rotate = 0,
  className,
  children,
}: {
  ready: boolean
  delay?: number
  y?: number
  x?: number
  rotate?: number
  className?: string
  children: ReactNode
}) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y, x, rotate }}
      animate={ready ? { opacity: 1, y: 0, x: 0, rotate: 0 } : undefined}
      transition={{ duration: 0.8, delay, ease: easeOut }}
    >
      {children}
    </motion.div>
  )
}

/** Running header across the top of the hero, like a notebook's page header. */
function PageHeader() {
  const [seconds, setSeconds] = useState(0)
  const [words, setWords] = useState(69)
  const { t, i18n } = useTranslation()
  const today = formatDate(LOADED_AT, i18n.language, 'short')
  useInterval(() => setSeconds((s) => s + 1), 1000)
  useInterval(() => setWords((w) => w + 3), 1250)
  const time = `${pad(Math.floor(seconds / 3600))}:${pad(Math.floor(seconds / 60) % 60)}:${pad(seconds % 60)}`

  return (
    <div className="mb-10 flex items-center justify-between border-b border-dashed border-warm/15 pb-3 font-mono text-[10px] uppercase tracking-[0.2em] text-steel">
      <span className="inline-flex items-center gap-2">
        <span className="relative flex h-1.5 w-1.5">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-neon opacity-70" />
          <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-neon" />
        </span>
        <span className="text-neon">{t('hero.header.vol')}</span>
        <span className="hidden sm:inline">{t('hero.header.entry', { code: profile.missionCode })}</span>
      </span>
      <span className="hidden items-center gap-4 sm:flex">
        <span>{t('hero.header.writing', { time })}</span>
        <span>{t('hero.header.words', { count: pad(words, 3) })}</span>
        <span>{today}</span>
      </span>
      <span>{t('hero.header.page')}</span>
    </div>
  )
}

/** The big open notebook page, tilting gently with the pointer. */
function NotebookPage({ ready, children }: { ready: boolean; children: ReactNode }) {
  const rx = useMotionValue(0)
  const ry = useMotionValue(0)
  const rotateX = useSpring(rx, { stiffness: 120, damping: 20 })
  const rotateY = useSpring(ry, { stiffness: 120, damping: 20 })
  const onMove = (e: PointerEvent<HTMLDivElement>) => {
    if (e.pointerType !== 'mouse') return
    const r = e.currentTarget.getBoundingClientRect()
    ry.set(((e.clientX - r.left) / r.width - 0.5) * 4)
    rx.set(-((e.clientY - r.top) / r.height - 0.5) * 3)
  }

  return (
    <div style={{ perspective: 1600 }}>
      <motion.div
        onPointerMove={onMove}
        onPointerLeave={() => {
          rx.set(0)
          ry.set(0)
        }}
        style={{ rotateX, rotateY, transformStyle: 'preserve-3d' }}
        initial={{ opacity: 0, rotateX: 18, y: 40 }}
        animate={ready ? { opacity: 1, rotateX: 0, y: 0 } : undefined}
        transition={{ duration: 1, delay: 0.35, ease: easeOut }}
        className="relative"
      >
        {/* stacked pages behind */}
        <div className="absolute inset-x-3 -bottom-2 top-2 rounded-2xl bg-warm/25 dark:bg-warm/[0.05]" />
        <div className="absolute inset-x-1.5 -bottom-1 top-1 rounded-2xl bg-warm/55 dark:bg-warm/10" />
        {/* open notebook + pencil resting on the desk, overlapping the page corner */}
        <img
          src={mockImages.hero}
          alt=""
          aria-hidden="true"
          fetchPriority="high"
          className="pointer-events-none absolute -right-6 -top-[148px] z-20 hidden w-[230px] rotate-[5deg] drop-shadow-[0_24px_30px_rgba(0,0,0,0.55)] md:block lg:-right-14 lg:-top-[190px] lg:w-[300px]"
        />
        {/* spiral binding along the top */}
        <div className="absolute inset-x-8 -top-3 z-10 flex justify-between sm:inset-x-12" aria-hidden="true">
          {Array.from({ length: 18 }, (_, i) => (
            <span
              key={i}
              className={`h-7 w-2.5 rounded-full bg-gradient-to-b from-warm via-steel to-edge shadow-sm ${i % 2 ? 'hidden sm:block' : ''}`}
            />
          ))}
        </div>
        <div className="ruled paper-grain relative overflow-hidden rounded-2xl border border-card-border bg-sheet text-fg shadow-[0_40px_80px_-30px_rgba(0,0,0,0.85)] dark:ring-1 dark:ring-neon/10 [--line:2.25rem] [--margin:1.75rem] sm:[--margin:3.5rem]">
          {children}
        </div>
      </motion.div>
    </div>
  )
}

export function Hero({ ready }: { ready: boolean }) {
  const { t } = useTranslation()
  const sp = t('hero.headline.space')
  const [ink, setInk] = useState(88)
  useEffect(() => {
    const id = setInterval(() => setInk(85 + Math.round(Math.random() * 8)), 2200)
    return () => clearInterval(id)
  }, [])

  return (
    <section id="home" aria-label={t('hero.aria')} className="relative overflow-hidden bg-graphite pb-24 pt-24 text-warm">
      {/* graphite drafting desk */}
      <div className="drafting-grid pointer-events-none absolute inset-0 opacity-60 [mask-image:radial-gradient(ellipse_90%_70%_at_50%_30%,black,transparent)]" />
      <InkDots className="pointer-events-none absolute inset-0 h-full w-full" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[480px] bg-[radial-gradient(60%_60%_at_50%_0%,rgba(239,255,0,0.09),transparent_70%)]" />

      <div className="relative mx-auto max-w-6xl px-5">
        <Enter ready={ready} y={-8}>
          <PageHeader />
        </Enter>

        <div className="grid items-start gap-10 pb-20 lg:grid-cols-[210px_1fr_240px] lg:gap-10 lg:pb-24">
          <Enter ready={ready} x={-30} y={10} rotate={-6} delay={0.5} className="order-2 hidden lg:order-1 lg:mt-6 lg:block">
            <aside aria-label={t('hero.fieldNotes.aria')}>
              <MissionControl />
            </aside>
          </Enter>
          <Enter ready={ready} y={40} rotate={3} delay={0.1} className="order-1 flex justify-center lg:order-2">
            <IdCard />
          </Enter>
          <Enter ready={ready} x={30} y={10} rotate={6} delay={0.6} className="order-3 hidden lg:mt-10 lg:block">
            <aside aria-label={t('hero.blueprint.aria')}>
              <DeployTerminal start={ready} />
            </aside>
          </Enter>
        </div>

        <NotebookPage ready={ready}>
          <WireframeSketch start={ready} className="pointer-events-none absolute left-16 top-16 hidden w-44 xl:block" />
          <RenderedCard start={ready} className="pointer-events-none absolute right-12 top-20 hidden w-44 xl:block" />
          {/* dashed arrow between sketch and software */}
          <svg viewBox="0 0 120 40" className="pointer-events-none absolute right-60 top-10 hidden w-24 text-faint xl:block" fill="none" aria-hidden="true">
            <motion.path
              d="M4 30 C 40 4, 80 4, 112 22 M104 14 L 112 22 L 102 26"
              stroke="currentColor"
              strokeWidth="1.4"
              strokeDasharray="4 4"
              strokeLinecap="round"
              initial={{ opacity: 0 }}
              animate={ready ? { opacity: 1 } : undefined}
              transition={{ delay: 2.8, duration: 0.6 }}
            />
          </svg>

          <div className="relative px-6 pb-16 pl-12 pt-14 text-center sm:px-16 sm:pb-20 sm:pl-24 sm:pt-20">
            <Enter ready={ready} delay={0.6} y={10}>
              <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-card-border bg-bg-subtle px-3.5 py-1 font-mono text-[10px] uppercase tracking-[0.22em] text-primary">
                <BookOpen size={12} />
                {t('hero.chapter')}
              </span>
            </Enter>
            <Enter ready={ready} delay={0.7}>
              <h1 className="mx-auto max-w-3xl text-balance font-display text-[2.6rem] font-medium leading-[1.05] tracking-tight text-fg sm:text-6xl lg:text-7xl">
                <span className="mb-3 block font-hand text-2xl font-normal tracking-normal text-primary sm:text-3xl">
                  {t('hero.notebookOf', { name: profile.name })}
                </span>
                {t('hero.headline.before')}
                {sp}
                <InkUnderline variant="circle" start={ready} delay={1.2} className="italic text-primary dark:[text-shadow:0_0_28px_rgba(239,255,0,0.22)]">
                  {t('hero.headline.from')}
                </InkUnderline>
                {sp}
                {t('hero.headline.middle')}
                {sp}
                <InkUnderline variant="double" start={ready} delay={1.9} className="italic text-primary dark:[text-shadow:0_0_28px_rgba(239,255,0,0.22)]">
                  {t('hero.headline.to')}
                </InkUnderline>
                {t('hero.headline.after')}
              </h1>
            </Enter>
            <Enter ready={ready} delay={0.85}>
              <p className="mx-auto mt-8 max-w-xl text-balance text-base leading-[2.25rem] text-muted">{t('content.profile.tagline')}</p>
            </Enter>
            <Enter ready={ready} delay={1} className="mt-8 flex flex-wrap items-center justify-center gap-3">
              <a
                href="#projects"
                className="group relative inline-flex items-center gap-2 overflow-hidden rounded-full bg-cta px-6 py-3 text-sm font-semibold text-on-cta shadow-[0_10px_30px_-12px_rgba(0,0,0,0.6)] transition-all hover:-translate-y-0.5 hover:bg-cta-hover dark:shadow-neon-sm dark:hover:shadow-neon"
              >
                <BookOpen size={16} className="transition-transform group-hover:-rotate-6" />
                {t('hero.cta.read')}
                <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
              </a>
              {profile.cvUrl && (
                <a
                  href={profile.cvUrl}
                  className="inline-flex items-center gap-2 rounded-full border border-card-border bg-sheet px-6 py-3 text-sm font-medium text-fg transition-all hover:-translate-y-0.5 hover:border-primary hover:text-primary"
                >
                  <Download size={16} />
                  {t('hero.cta.cv')}
                </a>
              )}
              <a
                href={`mailto:${socials.email}`}
                className="inline-flex items-center gap-2 rounded-full border border-card-border bg-sheet px-6 py-3 text-sm font-medium text-fg transition-all hover:-translate-y-0.5 hover:border-primary hover:text-primary"
              >
                <Mail size={16} />
                {t('hero.cta.hello')}
              </a>
            </Enter>
          </div>

          {/* status line along the bottom of the page */}
          <div className="relative flex flex-wrap items-center justify-between gap-x-8 gap-y-2 border-t border-dashed border-card-border bg-bg-subtle/60 px-6 py-3 pl-12 font-mono text-[10px] uppercase tracking-[0.18em] text-faint sm:pl-24 sm:pr-10">
            <span className="inline-flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-accent" />
              {t('hero.statusbar.saved')}
            </span>
            <span className="hidden sm:inline">
              ✎ {t('hero.statusbar.writing')} <span className="text-fg">{t('content.profile.flightPlan')}</span>
            </span>
            <span className="hidden md:inline">
              {t('hero.statusbar.author')} <span className="text-fg">{t('content.profile.payload')}</span>
            </span>
            <span className="inline-flex items-center gap-2">
              <span>{t('hero.statusbar.ink')}</span>
              <span className="inline-block h-1 w-16 overflow-hidden rounded-full bg-line">
                <span className="block h-full bg-primary transition-[width] duration-700" style={{ width: `${ink}%` }} />
              </span>
              <span className="text-fg">{ink}%</span>
            </span>
          </div>
        </NotebookPage>
      </div>

      {/* deckled paper edge into the next section */}
      <svg viewBox="0 0 1440 40" preserveAspectRatio="none" className="absolute inset-x-0 bottom-0 h-8 w-full text-bg" aria-hidden="true">
        <path
          d="M0 40 V22 C 80 18, 140 26, 220 21 S 380 14, 470 20 S 640 27, 730 19 S 900 13, 990 20 S 1170 27, 1260 19 S 1400 16, 1440 20 V40 Z"
          fill="currentColor"
        />
      </svg>
    </section>
  )
}
