import { ArrowUpRight, Globe, Paperclip, Sparkles } from 'lucide-react'
import { useTranslation } from 'react-i18next'
import { Reveal } from '../components/ui/Reveal'
import { SectionHeading } from '../components/ui/SectionHeading'
import { MockBadge } from '../components/ui/MockBadge'
import { StatusPill } from '../components/ui/StatusPill'
import { mockImages, pickImage } from '../data/images'
import { featuredProject, projects, socials, type Project } from '../data/portfolio'
import { GithubIcon } from '../lib/icons'

const alpha = (hex: string, a: number) =>
  `${hex}${Math.round(a * 255)
    .toString(16)
    .padStart(2, '0')}`

type ProjectText = { tagline?: string; description: string; highlights: string[] }

/** A project's translated text (content.projects.<slug> in the locale files). */
function useProjectText(slug: string): ProjectText {
  const { t } = useTranslation()
  const text = t(`content.projects.${slug}` as 'content.projects.featured-project', { returnObjects: true }) as unknown
  return typeof text === 'object' && text ? (text as ProjectText) : { description: '', highlights: [] }
}

const displayUrl = (p: Project) =>
  (p.liveUrl || p.repoUrl || `github.com/${socials.github.label.replace('@', '')}/${p.slug}`).replace(/^https?:\/\//, '')

/**
 * Preview "pinned" to the page: a sketched browser frame holding the screenshot.
 * Without a real screenshot it shows a labelled concept illustration (src/data/images.ts),
 * and failing that a pencil wireframe.
 */
function Preview({ project, className, large = false }: { project: Project; className: string; large?: boolean }) {
  const { t } = useTranslation()
  const { accent } = project
  const image = pickImage(project.image, mockImages.projects[project.slug])
  return (
    <div className={`relative overflow-hidden rounded-md border border-card-border bg-bg-elevated ${className}`}>
      <div className="grid-bg absolute inset-0" style={{ backgroundColor: alpha(accent, 0.05) }} />
      <div className="relative flex items-center gap-2 border-b border-card-border bg-sheet/80 px-3 py-2">
        {[0, 1, 2].map((i) => (
          <span key={i} className="h-2.5 w-2.5 rounded-full border border-faint/60" />
        ))}
        <div className="mx-auto max-w-[70%] truncate rounded-sm border border-dashed border-card-border px-3 py-0.5 font-mono text-[10px] text-faint">
          {displayUrl(project)}
        </div>
      </div>
      {/* cards use a 16:9 image area; the featured spread fills its column */}
      <div className={`relative overflow-hidden ${large ? 'h-[calc(100%-2.25rem)]' : 'aspect-video'}`}>
        {image ? (
          <>
            <img
              src={image.src}
              alt={image.isMock ? t('images.alt.project', { name: project.name }) : t('projects.previewAlt', { name: project.name })}
              loading="lazy"
              decoding="async"
              className={`absolute inset-0 h-full w-full transition-transform duration-700 group-hover:scale-105 ${
                !image.isMock && project.imageFit === 'contain' ? `object-contain ${large ? 'p-10' : 'p-6'}` : 'object-cover object-top'
              }`}
            />
            {image.isMock && <MockBadge kind="concept" className="absolute right-2.5 top-2.5" />}
          </>
        ) : (
          <>
            {/* pencil wireframe in the project's accent colour */}
            <svg viewBox="0 0 200 120" preserveAspectRatio="none" className="absolute inset-0 h-full w-full opacity-60" fill="none" aria-hidden="true">
              <g stroke={accent} strokeWidth="1" strokeLinecap="round" vectorEffect="non-scaling-stroke">
                <path d="M16 18 C 60 17, 120 19, 184 18" vectorEffect="non-scaling-stroke" />
                <path d="M16 34 L 96 33 L 97 92 L 17 93 Z" vectorEffect="non-scaling-stroke" />
                <path d="M110 36 C 140 35, 160 37, 182 36 M110 50 C 135 49, 150 51, 170 50 M110 64 C 130 63, 145 65, 160 64" vectorEffect="non-scaling-stroke" />
                <path d="M110 78 L 150 77 L 150 92 L 110 92 Z" vectorEffect="non-scaling-stroke" />
              </g>
            </svg>
            <div className="relative flex h-full items-center justify-center">
              <div
                className={`font-display font-medium italic text-primary transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-110 ${
                  large ? 'text-8xl' : 'text-5xl'
                }`}
              >
                {project.name.replace(/[^A-Za-z]/g, '').charAt(0) || 'P'}
              </div>
            </div>
          </>
        )}
        <span className="pointer-events-none absolute bottom-2 left-2.5 rounded-sm bg-graphite/85 px-1.5 font-hand text-[15px] leading-snug text-neon">
          ~/{project.slug}
        </span>
      </div>
    </div>
  )
}

function Status({ project }: { project: Project }) {
  const { t } = useTranslation()
  return project.liveUrl ? (
    <StatusPill label={t('projects.live')} />
  ) : (
    <span className="inline-flex items-center gap-1 text-[11px] font-medium text-faint">
      <span className="h-1.5 w-1.5 rounded-full bg-faint" />
      {t('projects.repoOnly')}
    </span>
  )
}

const Tags = ({ items, small = false }: { items: string[]; small?: boolean }) => (
  <div className="flex flex-wrap gap-1.5">
    {items.map((t) => (
      <span key={t} className={`rounded-full border border-card-border px-2.5 py-1 font-mono text-muted ${small ? 'text-[10.5px]' : 'text-[11px]'}`}>
        {t}
      </span>
    ))}
  </div>
)

const Highlights = ({ items, small = false }: { items: string[]; small?: boolean }) => (
  <ul className="space-y-0">
    {items.map((h, i) => (
      <li key={i} className={`flex gap-2 leading-8 text-muted ${small ? 'text-[13px]' : 'text-sm'}`}>
        <span className="font-hand text-lg text-primary">✓</span>
        {h}
      </li>
    ))}
  </ul>
)

/** The featured case study as an open notebook spread. */
function Featured({ project }: { project: Project }) {
  const { t } = useTranslation()
  const text = useProjectText(project.slug)
  return (
    <Reveal as="article" y={32} className="group relative">
      <div className="absolute inset-x-4 -bottom-2 top-2 rounded-2xl bg-line/70 dark:bg-warm/[0.06]" />
      <div className="relative grid overflow-hidden rounded-2xl border border-card-border bg-sheet shadow-paper lg:grid-cols-2">
        {/* centre spine */}
        <div className="pointer-events-none absolute inset-y-0 left-1/2 hidden w-16 -translate-x-1/2 bg-[linear-gradient(90deg,transparent,rgba(0,0,0,0.07)_45%,rgba(0,0,0,0.16)_50%,rgba(0,0,0,0.07)_55%,transparent)] lg:block" />

        <div className="ruled relative px-6 py-8 pl-16 [--line:2rem] [--margin:2.75rem] md:py-10 md:pr-12">
          <div className="mb-4 flex h-8 flex-wrap items-center gap-2">
            <span
              className="inline-flex items-center gap-1.5 rounded-full px-3 py-1 font-mono text-[10px] font-semibold uppercase tracking-wider"
              style={{ background: 'var(--primary-glow)', color: 'var(--primary)' }}
            >
              <Sparkles size={12} />
              {t('projects.featured')}
            </span>
            <Status project={project} />
          </div>
          <h3 className="font-display text-3xl font-medium leading-[2.5rem] tracking-tight md:text-4xl md:leading-[3rem]">{project.name}</h3>
          {text.tagline && <p className="font-hand text-2xl leading-8 text-primary">{text.tagline}</p>}
          <p className="mt-4 text-[15px] leading-8 text-muted">{text.description}</p>
          <div className="mt-4">
            <Highlights items={text.highlights} />
          </div>
          <div className="mt-5">
            <Tags items={project.tech} />
          </div>
          <div className="mt-7 flex flex-wrap gap-3">
            {project.liveUrl && (
              <a
                href={project.liveUrl}
                target="_blank"
                rel="noreferrer"
                className="group/btn inline-flex items-center gap-2 rounded-full bg-cta px-5 py-2.5 text-sm font-semibold text-on-cta transition-all hover:-translate-y-0.5 hover:bg-cta-hover dark:hover:shadow-neon-sm"
              >
                <Globe size={16} />
                {t('projects.visitLive')}
                <ArrowUpRight size={16} className="transition-transform group-hover/btn:-translate-y-0.5 group-hover/btn:translate-x-0.5" />
              </a>
            )}
            <a
              href={project.repoUrl || socials.github.url}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-full border border-card-border bg-sheet px-5 py-2.5 text-sm font-semibold transition-all hover:-translate-y-0.5 hover:border-primary hover:text-primary"
            >
              <GithubIcon size={16} />
              {t('projects.viewRepo')}
            </a>
          </div>
        </div>

        <div className="grid-bg relative p-6 md:p-10">
          <div className="relative h-full min-h-[300px] rotate-[1.2deg] transition-transform duration-500 group-hover:rotate-0">
            <Paperclip size={34} strokeWidth={1.3} className="absolute -top-5 left-8 z-10 rotate-[18deg] text-faint" aria-hidden="true" />
            <Preview project={project} large className="h-full min-h-[300px] shadow-paper" />
          </div>
        </div>
      </div>
    </Reveal>
  )
}

/** A loose notebook page: binder holes, a folded corner that lifts, a slight page-turn on hover. */
function Card({ project, index }: { project: Project; index: number }) {
  const { t } = useTranslation()
  const text = useProjectText(project.slug)
  return (
    <Reveal as="article" y={28} delay={index * 0.08} className="group relative [perspective:1400px]">
      <div className="absolute inset-0 translate-x-1.5 translate-y-1.5 rounded-r-xl rounded-l-sm border border-card-border bg-bg-elevated/70" />
      <div className="dog-ear relative flex h-full origin-left flex-col rounded-r-xl rounded-l-sm border border-card-border bg-sheet shadow-paper transition-all duration-500 [--ear-bg:var(--bg-subtle)] group-hover:-translate-y-2 group-hover:[--ear:42px] group-hover:[transform:rotateY(-5deg)] group-hover:shadow-[0_30px_50px_-24px_rgba(0,0,0,0.5)]">
        {/* binder holes */}
        <div className="absolute inset-y-0 left-2 flex flex-col justify-around py-10" aria-hidden="true">
          {[0, 1, 2].map((i) => (
            <span key={i} className="h-3 w-3 rounded-full border border-card-border bg-bg-subtle shadow-inner" />
          ))}
        </div>
        <div className="flex flex-1 flex-col py-5 pl-9 pr-5">
          <div className="mb-3 flex items-center justify-between">
            <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-faint">
              {t('projects.caseStudy', { n: String(index + 1).padStart(2, '0') })}
            </span>
          </div>
          <Preview project={project} className="" />
          <div className="mt-5 flex items-start justify-between gap-3">
            <div>
              <h3 className="font-display text-xl font-medium leading-tight transition-colors group-hover:text-primary">{project.name}</h3>
              <div className="mt-1.5">
                <Status project={project} />
              </div>
            </div>
            <ArrowUpRight
              size={20}
              className="shrink-0 text-faint transition-all group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-primary"
            />
          </div>
          <p className="mt-3 text-sm leading-relaxed text-muted">{text.description}</p>
          <div className="mt-2">
            <Highlights items={text.highlights} small />
          </div>
          <div className="mt-auto space-y-4 pt-4">
            <Tags items={project.tech} small />
            <div className="flex gap-2 border-t border-dashed border-card-border pt-4">
              {project.liveUrl && (
                <a
                  href={project.liveUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-full bg-cta px-3 py-2 text-xs font-semibold text-on-cta transition-colors hover:bg-cta-hover"
                >
                  <Globe size={14} />
                  {t('projects.liveShort')}
                </a>
              )}
              <a
                href={project.repoUrl || socials.github.url}
                target="_blank"
                rel="noreferrer"
                className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-full border border-card-border px-3 py-2 text-xs font-semibold transition-colors hover:border-primary hover:text-primary"
              >
                <GithubIcon size={14} />
                {t('projects.repo')}
              </a>
            </div>
          </div>
        </div>
      </div>
    </Reveal>
  )
}

export function Projects() {
  const { t } = useTranslation()
  return (
    <section id="projects" className="relative bg-bg-subtle py-24 md:py-32">
      <div className="grid-bg pointer-events-none absolute inset-0 opacity-60 [mask-image:linear-gradient(to_bottom,black,transparent_60%)]" />
      <div className="relative mx-auto max-w-6xl px-5">
        <SectionHeading index="05" eyebrow={t('projects.eyebrow')} title={t('projects.title')} />
        <div className="space-y-12">
          <Featured project={featuredProject} />
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {projects.map((p, i) => (
              <Card key={p.slug} project={p} index={i} />
            ))}
          </div>
          <Reveal y={16} tilt={0} className="flex justify-center pt-2">
            <a
              href={socials.github.url}
              target="_blank"
              rel="noreferrer"
              className="group inline-flex items-center gap-2 rounded-full border border-card-border bg-sheet px-5 py-2.5 text-sm font-medium text-muted shadow-paper transition-all hover:-translate-y-0.5 hover:border-primary hover:text-primary"
            >
              <GithubIcon size={16} />
              {t('projects.more')}
              <ArrowUpRight size={16} className="transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </a>
          </Reveal>
        </div>
      </div>
    </section>
  )
}
