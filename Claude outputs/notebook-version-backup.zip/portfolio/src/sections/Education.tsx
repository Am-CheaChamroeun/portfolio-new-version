import { ArrowUpRight, Calendar, GraduationCap } from 'lucide-react'
import { useTranslation } from 'react-i18next'
import { Reveal } from '../components/ui/Reveal'
import { SectionHeading } from '../components/ui/SectionHeading'
import { StatusPill } from '../components/ui/StatusPill'
import { mockImages, pickImage } from '../data/images'
import { education, type EducationItem } from '../data/portfolio'

function ChapterCard({ item }: { item: EducationItem }) {
  const { t } = useTranslation()
  const logo = pickImage(item.logo, mockImages.education[item.id])
  const details = t(`content.education.${item.id}.details` as 'content.education.edu-1.details', { returnObjects: true, defaultValue: [] }) as string[]
  const cls =
    'group ruled dog-ear relative block rounded-r-xl rounded-l-sm border border-card-border bg-sheet py-6 pl-16 pr-8 shadow-paper transition-all duration-300 [--ear-bg:var(--bg-subtle)] [--line:2rem] [--margin:2.75rem] hover:-translate-y-1 hover:rotate-[-0.35deg] hover:[--ear:36px] hover:shadow-[0_28px_50px_-24px_rgba(0,0,0,0.45)]'
  const body = (
    <>
      {item.url && (
        <span className="absolute right-10 top-4 z-10 inline-flex items-center gap-1 rounded-full border border-card-border bg-bg-subtle px-2.5 py-1 text-[10px] font-medium text-primary opacity-0 transition-all duration-300 group-hover:opacity-100">
          {t('education.visit')}
          <ArrowUpRight size={11} />
        </span>
      )}
      <div className="mb-3 flex flex-wrap items-center gap-3">
        <div className="relative flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-lg border border-card-border bg-warm">
          {logo ? (
            <img
              src={logo.src}
              // mock emblems are decorative; a real logo gets a proper alt text
              alt={logo.isMock ? '' : t('education.logoAlt', { school: item.school })}
              loading="lazy"
              decoding="async"
              className="h-full w-full object-contain p-1"
            />
          ) : (
            <GraduationCap size={22} strokeWidth={1.6} className="text-graphite" />
          )}
        </div>
        <span className="inline-flex items-center gap-1.5 rounded-full border border-card-border bg-bg-subtle px-3 py-1 font-mono text-[11px] text-muted">
          <Calendar size={12} />
          {item.period}
        </span>
        {item.current && <StatusPill label={t('education.current')} />}
      </div>
      <h3 className="font-display text-xl font-medium leading-8 text-fg transition-colors group-hover:text-primary md:text-2xl md:leading-[2.5rem]">
        {item.school}
      </h3>
      <ul>
        {details.map((d, i) => (
          <li key={i} className="flex items-start gap-3 text-[15px] leading-8 text-muted">
            <span className="font-hand text-xl leading-8 text-primary">—</span>
            <span>{d}</span>
          </li>
        ))}
      </ul>
    </>
  )

  return item.url ? (
    <a href={item.url} target="_blank" rel="noreferrer" aria-label={t('education.visitAria', { school: item.school })} className={cls}>
      {body}
    </a>
  ) : (
    <div className={cls}>{body}</div>
  )
}

export function Education() {
  const { t } = useTranslation()
  return (
    <section id="education" className="relative bg-bg-subtle py-24 md:py-32">
      <div className="grid-bg pointer-events-none absolute inset-0 opacity-60 [mask-image:linear-gradient(to_bottom,black,transparent_70%)]" />
      <div className="relative mx-auto max-w-6xl px-5">
        <div className="relative">
          <SectionHeading index="02" eyebrow={t('education.eyebrow')} title={t('education.title')} />
          <img
            src={mockImages.educationDecoration}
            alt=""
            aria-hidden="true"
            loading="lazy"
            decoding="async"
            className="pointer-events-none absolute -top-6 right-0 hidden w-56 rotate-[-4deg] md:block lg:w-64"
          />
        </div>
        <div className="relative">
          {/* chapter spine */}
          <div className="absolute bottom-4 left-[19px] top-4 w-px bg-[repeating-linear-gradient(to_bottom,var(--border-strong)_0_4px,transparent_4px_9px)] md:left-[150px]" />
          <div className="space-y-10">
            {education.map((item, i) => (
              <Reveal key={i} y={30} className="relative grid gap-4 md:grid-cols-[150px_1fr] md:gap-12">
                <span className="absolute left-[12px] top-7 z-10 flex h-4 w-4 items-center justify-center rounded-full border-2 border-primary bg-bg-subtle md:left-[143px]">
                  {item.current && <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-accent opacity-50" />}
                  <span className="relative h-1.5 w-1.5 rounded-full bg-primary" />
                </span>
                <div className="pl-12 md:pl-0 md:pr-8 md:text-right">
                  <div className="font-mono text-[10px] uppercase tracking-[0.25em] text-faint">{t('education.chapter', { n: i + 1 })}</div>
                  <div className="font-display text-5xl font-light leading-none text-transparent [-webkit-text-stroke:1px_var(--primary)] md:text-7xl">
                    {String(i + 1).padStart(2, '0')}
                  </div>
                </div>
                <div className="pl-12 md:pl-0">
                  <ChapterCard item={item} />
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
