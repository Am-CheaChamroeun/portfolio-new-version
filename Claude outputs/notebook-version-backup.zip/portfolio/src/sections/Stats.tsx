import { animate, motion, useInView } from 'motion/react'
import { useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Reveal } from '../components/ui/Reveal'
import { stats } from '../data/portfolio'

function Counter({ value, suffix }: { value: number; suffix: string }) {
  const ref = useRef<HTMLSpanElement>(null)
  const inView = useInView(ref, { once: true, margin: '-40px' })
  const [n, setN] = useState(0)
  useEffect(() => {
    if (!inView) return
    const controls = animate(0, value, { duration: 2, ease: [0.16, 1, 0.3, 1], onUpdate: (v) => setN(Math.round(v)) })
    return () => controls.stop()
  }, [inView, value])
  return (
    <span ref={ref} className="tabular-nums">
      {n}
      <span className="italic text-primary">{suffix}</span>
    </span>
  )
}

export function Stats() {
  const { t } = useTranslation()
  return (
    <section className="lined relative border-y border-card-border bg-sheet py-20 [--line:2.5rem]" aria-label={t('stats.aria')}>
      <div className="relative mx-auto grid max-w-6xl grid-cols-2 gap-y-12 px-5 lg:grid-cols-4">
        {stats.map((s, i) => (
          <Reveal
            key={s.id}
            delay={i * 0.08}
            className={`relative px-4 text-center ${i % 2 ? 'border-l border-dashed border-card-border' : ''} ${
              i === 2 ? 'lg:border-l lg:border-dashed lg:border-card-border' : ''
            }`}
          >
            <div className="font-display text-5xl font-medium tracking-tight text-fg md:text-7xl">
              <Counter value={s.value} suffix={s.suffix} />
            </div>
            <svg viewBox="0 0 120 10" className="mx-auto mt-1 h-2.5 w-24" fill="none" aria-hidden="true">
              <motion.path
                d="M2 6 C 30 2, 70 9, 118 4"
                className="stroke-accent"
                strokeWidth="2.5"
                strokeLinecap="round"
                initial={{ pathLength: 0 }}
                whileInView={{ pathLength: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.5 + i * 0.1 }}
              />
            </svg>
            <div className="mt-2 font-hand text-2xl leading-tight text-muted">{t(`content.stats.${s.id}` as 'content.stats.projects')}</div>
          </Reveal>
        ))}
      </div>
    </section>
  )
}
