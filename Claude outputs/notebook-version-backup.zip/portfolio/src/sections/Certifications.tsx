import { Award, Eye, X } from 'lucide-react'
import { AnimatePresence, motion } from 'motion/react'
import { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Reveal } from '../components/ui/Reveal'
import { SectionHeading } from '../components/ui/SectionHeading'
import { MockBadge } from '../components/ui/MockBadge'
import { mockImages, pickImage } from '../data/images'
import { certificates, profile, type Certificate } from '../data/portfolio'

/** Stand-in document shown until you add a real certificate image. */
function CertificatePlaceholder({ cert, large = false }: { cert: Certificate; large?: boolean }) {
  const { t } = useTranslation()
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-bg-subtle p-[6%]">
      <div className="relative flex h-full w-full flex-col items-center justify-center border-[3px] border-double border-accent/50 bg-sheet text-center text-fg">
        <Award className="mb-[3%] text-primary" size={large ? 56 : 30} strokeWidth={1.4} />
        <div className={`font-display font-medium uppercase tracking-[0.2em] ${large ? 'text-2xl' : 'text-[13px]'}`}>
          {t('certifications.placeholder.heading')}
        </div>
        <div className={`mt-[2%] text-muted ${large ? 'text-base' : 'text-[10px]'}`}>{t('certifications.placeholder.awarded')}</div>
        <div className={`mt-[1%] font-hand ${large ? 'text-5xl' : 'text-2xl'} text-primary`}>{profile.name}</div>
        <div className={`mt-[2%] px-[8%] text-muted ${large ? 'text-base' : 'text-[10px]'}`}>{cert.title}</div>
        <div className="absolute bottom-[6%] font-mono text-[9px] uppercase tracking-[0.2em] text-faint">
          {t('certifications.placeholder.add')}
        </div>
      </div>
    </div>
  )
}

/** Real certificate scan, or a sample layout until you add one. */
const certImage = (cert: Certificate) => pickImage(cert.image, mockImages.certificates[certificates.indexOf(cert)])

function Lightbox({ cert, onClose }: { cert: Certificate; onClose: () => void }) {
  const { t } = useTranslation()
  const image = certImage(cert)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    document.addEventListener('keydown', onKey)
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = prev
    }
  }, [onClose])

  return (
    <motion.div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-graphite/90 p-6 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label={t('certifications.dialog', { title: cert.title })}
      onClick={onClose}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <motion.div
        className="relative max-h-[90vh] w-full max-w-5xl overflow-hidden rounded-sm bg-sheet shadow-2xl ring-1 ring-edge"
        onClick={(e) => e.stopPropagation()}
        initial={{ opacity: 0, rotateX: 12, y: 30 }}
        animate={{ opacity: 1, rotateX: 0, y: 0 }}
        exit={{ opacity: 0, rotateX: -8, y: 20 }}
        transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        style={{ transformPerspective: 1400 }}
      >
        <button
          type="button"
          autoFocus
          onClick={onClose}
          aria-label={t('certifications.close')}
          className="absolute right-3 top-3 z-10 flex h-9 w-9 items-center justify-center rounded-full bg-graphite text-warm ring-1 ring-edge transition-colors hover:bg-neon hover:text-graphite"
        >
          <X size={18} />
        </button>
        {image ? (
          <div className="relative">
            <img
              src={image.src}
              alt={
                image.isMock
                  ? t('images.alt.certificate', { title: cert.title })
                  : t('certifications.issuedBy', { title: cert.title, issuer: cert.issuerFull ?? cert.issuer })
              }
              className="h-auto max-h-[90vh] w-full object-contain"
            />
            {image.isMock && <MockBadge kind="sample" className="absolute left-4 top-4" />}
          </div>
        ) : (
          <div className="relative aspect-[7/5] w-full">
            <CertificatePlaceholder cert={cert} large />
          </div>
        )}
        <div className="absolute inset-x-0 bottom-0 flex items-center gap-3 border-t border-card-border bg-sheet/95 px-5 py-3 backdrop-blur">
          <div className="min-w-0 flex-1">
            <div className="truncate font-display text-base font-medium text-fg">{cert.title}</div>
            <div className="truncate font-mono text-[10.5px] uppercase tracking-wider text-muted">
              {cert.issuerFull ?? cert.issuer} · {cert.date}
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  )
}

export function Certifications() {
  const { t } = useTranslation()
  const [open, setOpen] = useState<Certificate | null>(null)

  return (
    <section id="certificates" className="relative mx-auto max-w-6xl px-5 py-24 md:py-32">
      <SectionHeading index="04" eyebrow={t('certifications.eyebrow')} title={t('certifications.title')} />

      <div className="grid gap-8 md:grid-cols-2">
        {certificates.map((cert, i) => {
          const image = certImage(cert)
          return (
          <Reveal key={i} as="article" y={28} delay={i * 0.08} className="group relative">
            {/* paper stack */}
            <div className="absolute inset-0 translate-x-2 translate-y-2 rotate-[1deg] rounded-sm border border-card-border bg-bg-subtle transition-transform duration-500 group-hover:translate-x-3 group-hover:translate-y-3 group-hover:rotate-[2deg]" />
            <div className="relative rounded-sm border border-card-border bg-sheet p-3 shadow-paper transition-transform duration-500 group-hover:-translate-y-1.5 group-hover:rotate-[-0.5deg]">
              <div
                role="button"
                tabIndex={0}
                aria-label={t('certifications.viewAria', { title: cert.title })}
                onClick={() => setOpen(cert)}
                onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), setOpen(cert))}
                className="relative aspect-[7/5] w-full cursor-pointer overflow-hidden border border-card-border bg-bg-subtle focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]"
              >
                <div className="absolute inset-0 transition-transform duration-700 group-hover:scale-[1.03]">
                  {image ? (
                    <img
                      src={image.src}
                      alt={image.isMock ? t('images.alt.certificate', { title: cert.title }) : t('certifications.previewAlt', { title: cert.title })}
                      loading="lazy"
                      decoding="async"
                      className="h-full w-full object-cover object-top"
                    />
                  ) : (
                    <CertificatePlaceholder cert={cert} />
                  )}
                </div>
                {image?.isMock && <MockBadge kind="sample" className="absolute left-3 top-3" />}
                <div className="pointer-events-none absolute right-3 top-3 rotate-[2deg] rounded-sm bg-cta px-2 py-1 font-mono text-[10px] uppercase tracking-wider text-on-cta shadow">
                  {cert.date}
                </div>
                <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-graphite/0 opacity-0 transition-all duration-300 group-hover:bg-graphite/60 group-hover:opacity-100">
                  <span className="inline-flex items-center gap-2 rounded-full bg-neon px-4 py-2 text-sm font-semibold text-graphite shadow-neon">
                    <Eye size={16} />
                    {t('certifications.view')}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-4 px-2 pb-1 pt-4">
                {/* embossed seal */}
                <span className="relative flex h-11 w-11 shrink-0 items-center justify-center rounded-full border-2 border-dashed border-primary/50 font-display text-base font-semibold text-primary">
                  {cert.issuer.replace(/[^A-Za-z]/g, '').charAt(0) || '★'}
                </span>
                <div className="min-w-0">
                  <div className="truncate font-mono text-[10.5px] uppercase tracking-[0.16em] text-faint">{cert.issuer}</div>
                  <h3 className="font-display text-lg font-medium leading-snug text-fg">{cert.title}</h3>
                </div>
              </div>
            </div>
          </Reveal>
          )
        })}
      </div>

      <Reveal as="p" y={0} tilt={0} className="mt-14 text-center font-hand text-xl text-faint">
        {t('certifications.hint')}
      </Reveal>

      <AnimatePresence>{open && <Lightbox cert={open} onClose={() => setOpen(null)} />}</AnimatePresence>
    </section>
  )
}
