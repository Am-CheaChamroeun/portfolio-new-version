import { useTranslation } from 'react-i18next'
import { Reveal } from '../components/ui/Reveal'
import { SectionHeading } from '../components/ui/SectionHeading'
import { mockImages } from '../data/images'
import { highlightedServices, services } from '../data/portfolio'

/** Small registration cross used at the corners of each drawing. */
const Cross = ({ className }: { className: string }) => (
  <svg viewBox="0 0 12 12" className={`absolute h-3 w-3 text-neon/50 ${className}`} aria-hidden="true">
    <path d="M6 0v12M0 6h12" stroke="currentColor" strokeWidth="1" />
  </svg>
)

export function Services() {
  const { t } = useTranslation()
  const words = t('services.numbers', { returnObjects: true })
  return (
    <section id="services" className="relative overflow-hidden bg-graphite py-24 text-warm md:py-32">
      <div className="drafting-grid pointer-events-none absolute inset-0 opacity-80" />
      <div className="relative mx-auto max-w-6xl px-5">
        <SectionHeading index="06" eyebrow={t('services.eyebrow')} title={t('services.title')} tone="light" />
        <Reveal as="p" y={0} tilt={0} className="-mt-8 mb-12 max-w-md font-mono text-[11px] uppercase tracking-[0.18em] text-steel">
          {t('services.subline', { count: words[services.length] ?? services.length })}
        </Reveal>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s, i) => {
            const hot = i < highlightedServices
            const Icon = s.icon
            const num = String(i + 1).padStart(2, '0')
            const title = t(`content.services.${s.id}.title` as 'content.services.frontend.title')
            const description = t(`content.services.${s.id}.description` as 'content.services.frontend.description')
            return (
              <Reveal
                key={s.id}
                as="article"
                y={28}
                delay={(i % 3) * 0.08}
                className={`group relative flex h-full min-h-[340px] flex-col border p-7 transition-colors duration-300 lg:p-8 ${
                  hot ? 'border-neon/45 bg-neon/[0.04]' : 'border-warm/15 hover:border-neon/40 hover:bg-warm/[0.03]'
                }`}
              >
                <Cross className="-left-1.5 -top-1.5" />
                <Cross className="-right-1.5 -top-1.5" />
                <Cross className="-bottom-1.5 -left-1.5" />
                <Cross className="-bottom-1.5 -right-1.5" />

                {/* dimension line */}
                <div className="flex items-center gap-2 font-mono text-[9px] uppercase tracking-[0.2em] text-steel/80">
                  <span className="h-2 w-px bg-neon/40" />
                  <span className="h-px flex-1 bg-warm/20" />
                  <span>{t('services.fig', { n: num })}</span>
                  <span className="h-px flex-1 bg-warm/20" />
                  <span className="h-2 w-px bg-neon/40" />
                </div>

                <div className="mt-6 flex items-start justify-between">
                  <span
                    className={`font-display text-[64px] font-light leading-[0.85] tracking-tight transition-colors duration-300 lg:text-[80px] ${
                      hot ? 'text-neon' : 'text-transparent [-webkit-text-stroke:1px_rgba(245,245,233,0.45)] group-hover:text-neon/20'
                    }`}
                  >
                    {num}
                  </span>
                  <span className="flex h-12 w-12 items-center justify-center rounded-full border border-dashed border-neon/50 text-neon transition-transform duration-500 group-hover:rotate-[20deg]">
                    <Icon size={20} strokeWidth={1.3} />
                  </span>
                </div>

                {mockImages.specializations[s.id] && (
                  <img
                    src={mockImages.specializations[s.id]}
                    alt=""
                    aria-hidden="true"
                    loading="lazy"
                    decoding="async"
                    className={`mt-7 h-16 w-auto transition-opacity duration-300 ${hot ? 'opacity-95' : 'opacity-60 group-hover:opacity-95'}`}
                  />
                )}
                <h3 className="mt-6 font-display text-2xl font-medium tracking-tight text-warm">{title}</h3>
                <p className="mt-3 max-w-[34ch] text-sm leading-relaxed text-steel">{description}</p>
                <div className="mt-auto pt-8">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[10px] uppercase tracking-[0.22em] text-neon/70">{t('services.spec')}</span>
                    <div className="h-px flex-1 border-b border-dashed border-warm/20" />
                  </div>
                  <p className="mt-2.5 font-mono text-[11px] leading-relaxed text-warm/85">{s.stack}</p>
                </div>
              </Reveal>
            )
          })}
        </div>
        <Reveal as="p" y={0} tilt={0} className="mt-14 text-center font-hand text-2xl text-steel">
          {t('services.cta')}{' '}
          <a href="#contact" className="text-warm underline decoration-neon decoration-wavy underline-offset-4 transition-colors hover:text-neon hover:decoration-gold">
            {t('services.ctaLink')}
          </a>
        </Reveal>
      </div>
    </section>
  )
}
