import { AnimatePresence, motion } from 'motion/react'
import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Reveal } from '../components/ui/Reveal'
import { SectionHeading } from '../components/ui/SectionHeading'
import { mockImages } from '../data/images'
import { profile, skillGroups } from '../data/portfolio'
import { useInterval } from '../hooks/useInterval'
import { formatDate } from '../i18n'
import { TechIcon } from '../lib/icons'

const SEGMENTS = 12
const pad = (n: number) => String(n).padStart(2, '0')
const levelKey = (l: number) => (l >= 11 ? 'expert' : l >= 9 ? 'advanced' : l >= 7 ? 'proficient' : 'learning')

function useClock() {
  const [now, setNow] = useState(() => new Date())
  useInterval(() => setNow(new Date()), 1000)
  return now
}

export function Skills() {
  const { t, i18n } = useTranslation()
  const [active, setActive] = useState(0)
  const now = useClock()
  const group = skillGroups[active]
  const groupLabel = (key: string) => t(`content.skills.${key}` as 'content.skills.frontend')
  const revised = formatDate(now, i18n.language, 'iso')

  return (
    <section id="skills" className="relative mx-auto max-w-6xl px-5 py-24 md:py-32">
      <SectionHeading index="03" eyebrow={t('skills.eyebrow')} title={t('skills.title')} />

      <div className="grid items-start md:grid-cols-[210px_1fr]">
        {/* notebook divider tabs */}
        <div className="relative z-10 flex gap-2 overflow-x-auto pb-3 md:flex-col md:gap-1.5 md:overflow-visible md:pb-0 md:pt-8" role="tablist">
          {skillGroups.map((g, i) => {
            const selected = i === active
            const Icon = g.icon
            return (
              <button
                key={g.key}
                type="button"
                role="tab"
                aria-selected={selected}
                onClick={() => setActive(i)}
                className={`group relative flex shrink-0 items-center gap-3 rounded-lg px-4 py-3 text-left text-sm transition-all md:rounded-l-lg md:rounded-r-none md:border-y md:border-l ${
                  selected
                    ? 'bg-graphite text-neon md:-mr-px md:translate-x-0 md:border-graphite dark:bg-graphite-2 dark:md:border-edge'
                    : 'border border-card-border bg-sheet text-muted hover:text-fg md:mr-3 md:translate-x-3 md:hover:translate-x-1'
                }`}
              >
                <Icon size={16} strokeWidth={1.7} className="shrink-0" />
                <span className="whitespace-nowrap font-display text-[15px] font-medium">{groupLabel(g.key)}</span>
                <span className={`ml-auto hidden font-mono text-[10px] md:inline ${selected ? 'text-steel' : 'text-faint'}`}>
                  {pad(g.skills.length)}
                </span>
              </button>
            )
          })}
          <p className="hidden pl-1 pt-4 font-hand text-lg leading-snug text-faint md:block">{t('skills.hint')}</p>
          <img
            src={mockImages.skillsDecoration}
            alt=""
            aria-hidden="true"
            loading="lazy"
            decoding="async"
            className="pointer-events-none hidden w-40 pt-6 opacity-90 md:block"
          />
        </div>

        {/* drafting-grid index sheet */}
        <Reveal role="tabpanel" className="relative">
          <div className="drafting-grid relative overflow-hidden rounded-xl border border-graphite text-warm shadow-[0_30px_70px_-30px_rgba(0,0,0,0.7)] md:rounded-tl-none dark:border-edge">
            <div className="flex items-center justify-between border-b border-warm/15 px-5 py-3 font-mono text-[10px] uppercase tracking-[0.22em] text-neon/80">
              <span>{t('skills.index', { group: groupLabel(group.key) })}</span>
              <span className="hidden sm:inline">
                {pad(now.getHours())}:{pad(now.getMinutes())}:{pad(now.getSeconds())}
              </span>
            </div>

            <div className="min-h-[400px] p-5 md:p-7">
              <AnimatePresence mode="wait">
                <motion.div
                  key={group.key}
                  initial={{ opacity: 0, rotateY: -8, x: -10 }}
                  animate={{ opacity: 1, rotateY: 0, x: 0 }}
                  exit={{ opacity: 0, rotateY: 8, x: 10 }}
                  transition={{ duration: 0.3 }}
                  style={{ transformPerspective: 1200, transformOrigin: 'left center' }}
                >
                  <div className="mb-5 flex items-baseline justify-between">
                    <h3 className="font-display text-3xl font-medium text-warm">{groupLabel(group.key)}</h3>
                    <span className="font-hand text-xl text-neon/80">{t('skills.entries', { n: pad(group.skills.length) })}</span>
                  </div>
                  <ul className="space-y-1">
                    {group.skills.map((skill, i) => (
                      <motion.li
                        key={skill.name}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.05 + i * 0.06, duration: 0.3 }}
                        className="group grid grid-cols-[auto_1fr_auto] items-center gap-3 rounded px-2 py-2 transition-colors hover:bg-neon/[0.06] sm:grid-cols-[auto_auto_1fr_auto_84px]"
                      >
                        <span className="flex h-7 w-7 items-center justify-center rounded-md bg-warm">
                          <TechIcon name={skill.icon} size={16} />
                        </span>
                        <span className="truncate text-[15px] text-warm transition-colors group-hover:text-neon">{skill.name}</span>
                        {/* dotted leader, like a book index */}
                        <span className="hidden h-px self-center border-b border-dotted border-warm/25 sm:block" />
                        <span className="flex gap-[3px]" aria-label={t('skills.meterAria', { level: skill.level, max: SEGMENTS })}>
                          {Array.from({ length: SEGMENTS }, (_, s) => (
                            <motion.span
                              key={s}
                              initial={{ scaleY: 0 }}
                              animate={{ scaleY: 1 }}
                              transition={{ delay: 0.1 + i * 0.06 + s * 0.025, duration: 0.2 }}
                              className={`h-3 w-[3px] origin-bottom skew-x-[-14deg] rounded-[1px] ${s < skill.level ? 'bg-neon' : 'bg-warm/15'}`}
                            />
                          ))}
                        </span>
                        <span className="hidden text-right font-hand text-lg leading-none text-steel sm:inline">{t(`skills.levels.${levelKey(skill.level)}`)}</span>
                      </motion.li>
                    ))}
                  </ul>
                  <div className="mt-6 flex items-center gap-2 px-2 font-mono text-[10.5px] text-steel">
                    <span className="h-1.5 w-1.5 rounded-full bg-neon" />
                    <span>{t('skills.verified')}</span>
                    <span className="ml-auto hidden sm:inline">
                      {t('skills.revised', { date: revised })}
                    </span>
                  </div>
                  <div className="mt-3 px-2 font-mono text-[12px] text-steel">
                    ✎ <span className="inline-block h-3 w-1.5 translate-y-[1px] animate-pulse bg-neon" />
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>

            {/* engineering title block */}
            <div className="grid grid-cols-2 border-t border-warm/15 font-mono text-[9px] uppercase tracking-wider text-steel sm:grid-cols-4">
              <span className="border-r border-warm/15 px-4 py-2">{t('skills.drawnBy', { name: profile.name })}</span>
              <span className="px-4 py-2 sm:border-r sm:border-warm/15">
                {t('skills.sheet', { current: pad(active + 1), total: pad(skillGroups.length) })}
              </span>
              <span className="hidden border-r border-warm/15 px-4 py-2 sm:block">{t('skills.scale')}</span>
              <span className="hidden items-center gap-1.5 px-4 py-2 sm:flex">
                <span className="h-1.5 w-1.5 rounded-full bg-neon" />
                {t('skills.online')}
              </span>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
