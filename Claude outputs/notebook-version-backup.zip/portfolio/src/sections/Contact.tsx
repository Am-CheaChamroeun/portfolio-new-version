import { ArrowUpRight, CheckCircle2, Download, Mail, Send } from 'lucide-react'
import { useState, type FormEvent, type FormEventHandler, type ReactNode } from 'react'
import { useTranslation } from 'react-i18next'
import { Reveal } from '../components/ui/Reveal'
import { SectionHeading } from '../components/ui/SectionHeading'
import { mockImages } from '../data/images'
import { contactFormEndpoint, profile, socials } from '../data/portfolio'
import { GithubIcon, LinkedinIcon, TelegramIcon } from '../lib/icons'

type Status = 'idle' | 'sending' | 'sent' | 'error'

const inputCls =
  'w-full border-0 border-b-2 border-dashed border-line bg-transparent px-0 py-2 text-[15px] text-fg outline-none transition-colors placeholder:text-faint focus:border-solid focus:border-primary'
const labelCls = 'block font-hand text-xl leading-none text-primary'

function ContactLink({ href, icon, label, value }: { href: string; icon: ReactNode; label: string; value: string }) {
  const external = href.startsWith('http')
  return (
    <a
      href={href}
      {...(external && { target: '_blank', rel: 'noreferrer' })}
      className="group flex items-center gap-4 border-b border-dashed border-card-border py-3.5 transition-colors"
    >
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-card-border bg-sheet text-primary transition-all group-hover:-rotate-6 group-hover:border-primary">
        {icon}
      </span>
      <div className="min-w-0 flex-1">
        <div className="font-display text-base font-medium">{label}</div>
        <div className="truncate font-mono text-xs text-faint">{value}</div>
      </div>
      <ArrowUpRight size={18} className="shrink-0 text-faint transition-all group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-primary" />
    </a>
  )
}

export function Contact() {
  const { t } = useTranslation()
  const [status, setStatus] = useState<Status>('idle')

  /** Replace the browser's built-in validation bubble text with the current language. */
  const validation = {
    onInvalid: (e: FormEvent<HTMLInputElement | HTMLTextAreaElement>) => {
      const el = e.currentTarget
      el.setCustomValidity(el.validity.typeMismatch ? t('contact.validation.email') : t('contact.validation.required'))
    },
    onInput: (e: FormEvent<HTMLInputElement | HTMLTextAreaElement>) => e.currentTarget.setCustomValidity(''),
  }

  const onSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const data = Object.fromEntries(new FormData(form)) as Record<string, string>
    if (!contactFormEndpoint) {
      // No backend configured: hand the message to the visitor's email app.
      const subject = encodeURIComponent(t('contact.mailSubject', { name: data.name }))
      const body = encodeURIComponent(`${data.message}\n\n— ${data.name} (${data.email})`)
      window.location.href = `mailto:${socials.email}?subject=${subject}&body=${body}`
      setStatus('sent')
      return
    }
    setStatus('sending')
    try {
      const res = await fetch(contactFormEndpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(data),
      })
      if (!res.ok) throw new Error(String(res.status))
      form.reset()
      setStatus('sent')
    } catch {
      setStatus('error')
    }
  }

  return (
    <section id="contact" className="mx-auto max-w-6xl px-5 py-24 md:py-32">
      <SectionHeading index="07" eyebrow={t('contact.eyebrow')} title={t('contact.title')} />
      <div className="grid gap-12 lg:grid-cols-[1fr_1.2fr] lg:gap-16">
        <Reveal x={-24} y={0} className="space-y-7">
          <p className="text-base leading-8 text-muted md:text-lg">{t('content.profile.availability')}</p>
          <div>
            <p className="mb-1 font-mono text-[10px] uppercase tracking-[0.25em] text-faint">{t('contact.addressBook')}</p>
            <ContactLink href={`mailto:${socials.email}`} icon={<Mail size={18} />} label={t('contact.email')} value={socials.email} />
            <ContactLink href={socials.linkedin.url} icon={<LinkedinIcon size={18} />} label={t('contact.linkedin')} value={socials.linkedin.label} />
            <ContactLink href={socials.github.url} icon={<GithubIcon size={18} />} label={t('contact.github')} value={socials.github.label} />
            <ContactLink href={socials.telegram.url} icon={<TelegramIcon size={18} />} label={t('contact.telegram')} value={socials.telegram.label} />
          </div>
          {profile.cvUrl && (
            <a
              href={profile.cvUrl}
              className="inline-flex items-center gap-2 rounded-full border border-card-border bg-sheet px-6 py-3 text-sm font-semibold shadow-paper transition-all hover:-translate-y-0.5 hover:border-primary hover:text-primary"
            >
              <Download size={16} />
              {t('contact.cv')}
            </a>
          )}
        </Reveal>

        <Reveal
          as="form"
          x={24}
          y={0}
          onSubmit={onSubmit as unknown as FormEventHandler<HTMLDivElement>}
          className="paper-grain dog-ear relative rounded-r-2xl rounded-l-md border border-card-border bg-sheet p-7 pl-10 shadow-paper md:p-10 md:pl-14"
        >
          <span className="absolute inset-y-0 left-6 w-px bg-[var(--margin-line)] md:left-9" aria-hidden="true" />
          {/* envelope, letter and pencil resting on the corner of the page */}
          <img
            src={mockImages.contact}
            alt=""
            aria-hidden="true"
            loading="lazy"
            decoding="async"
            className="pointer-events-none absolute -right-4 -top-20 hidden w-44 rotate-[6deg] sm:block lg:-right-10 lg:-top-24 lg:w-52"
          />
          <p className="mb-8 font-hand text-3xl text-fg">{t('contact.dear', { name: profile.name })}</p>
          <div className="space-y-7">
            <div>
              <label htmlFor="name" className={labelCls}>
                {t('contact.labels.name')}
              </label>
              <input
                id="name"
                name="name"
                type="text"
                required
                autoComplete="name"
                placeholder={t('contact.placeholders.name')}
                className={inputCls}
                {...validation}
              />
            </div>
            <div>
              <label htmlFor="email" className={labelCls}>
                {t('contact.labels.email')}
              </label>
              <input
                id="email"
                name="email"
                type="email"
                required
                autoComplete="email"
                placeholder={t('contact.placeholders.email')}
                className={inputCls}
                {...validation}
              />
            </div>
            <div>
              <label htmlFor="message" className={labelCls}>
                {t('contact.labels.message')}
              </label>
              <textarea
                id="message"
                name="message"
                required
                rows={5}
                placeholder={t('contact.placeholders.message')}
                {...validation}
                className="lined mt-2 w-full resize-none border-0 bg-transparent text-[15px] leading-10 text-fg outline-none placeholder:text-faint [--line:2.5rem]"
              />
            </div>
            <button
              type="submit"
              disabled={status === 'sending'}
              className="flex w-full items-center justify-center gap-2 rounded-full bg-cta px-6 py-3.5 text-sm font-semibold text-on-cta transition-all hover:-translate-y-0.5 hover:bg-cta-hover disabled:opacity-70 dark:hover:shadow-neon-sm"
            >
              {status === 'sent' ? <CheckCircle2 size={16} /> : <Send size={16} />}
              {status === 'sending' ? t('contact.sending') : status === 'sent' ? t('contact.sent') : t('contact.submit')}
            </button>
            <p role="status" className="min-h-4 text-center text-xs text-faint">
              {status === 'error' && t('contact.error')}
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
