import { MotionConfig } from 'motion/react'
import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { BackToTop } from './components/effects/BackToTop'
import { PencilCursor } from './components/effects/PencilCursor'
import { ScrollProgress } from './components/effects/ScrollProgress'
import { ScrollPencil } from './components/effects/ScrollPencil'
import { Footer } from './components/layout/Footer'
import { Header } from './components/layout/Header'
import { Preloader } from './components/layout/Preloader'
import { About } from './sections/About'
import { Certifications } from './sections/Certifications'
import { Contact } from './sections/Contact'
import { Education } from './sections/Education'
import { Hero } from './sections/Hero'
import { Projects } from './sections/Projects'
import { Services } from './sections/Services'
import { Skills } from './sections/Skills'
import { Stats } from './sections/Stats'

export default function App() {
  const [ready, setReady] = useState(false)
  const { t } = useTranslation()

  return (
    <MotionConfig reducedMotion="user">
      <a
        href="#main"
        className="sr-only z-[70] rounded-md bg-sheet px-3 py-2 text-sm font-medium focus:not-sr-only focus:absolute focus:left-4 focus:top-4"
      >
        {t('nav.skip')}
      </a>
      <Preloader onDone={() => setReady(true)} />
      <PencilCursor />
      <ScrollProgress />
      <ScrollPencil />
      <Header />
      <main id="main">
        <Hero ready={ready} />
        <About />
        <Education />
        <Skills />
        <Certifications />
        <Projects />
        <Services />
        <Stats />
        <Contact />
      </main>
      <Footer />
      <BackToTop />
    </MotionConfig>
  )
}
