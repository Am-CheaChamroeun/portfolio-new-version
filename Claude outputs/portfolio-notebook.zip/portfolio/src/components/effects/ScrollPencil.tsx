import { motion, useScroll, useSpring, useTransform } from 'motion/react'
import { Pencil } from '../ui/Pencil'

/**
 * A pencil on the right edge that writes a line down the page as you scroll —
 * the line's length is your reading progress.
 */
export function ScrollPencil() {
  const { scrollYProgress } = useScroll()
  const p = useSpring(scrollYProgress, { stiffness: 90, damping: 24, restDelta: 0.0005 })
  const top = useTransform(p, (v) => `${v * 100}%`)
  const wobble = useTransform(p, (v) => Math.sin(v * Math.PI * 40) * 2.5)
  const opacity = useTransform(p, [0, 0.015, 0.04], [0, 0, 1])

  return (
    <motion.div
      aria-hidden="true"
      className="pointer-events-none fixed bottom-24 right-0.5 top-24 z-40 w-4 opacity-80 sm:right-4 sm:w-6 sm:opacity-100 lg:right-6"
      style={{ opacity }}
    >
      {/* faint dotted guide */}
      <div className="absolute inset-y-0 left-1/2 hidden w-px -translate-x-1/2 sm:block bg-[repeating-linear-gradient(to_bottom,var(--border-strong)_0_3px,transparent_3px_8px)] opacity-70" />
      {/* ink written so far */}
      <motion.div
        className="absolute left-1/2 top-0 w-[2px] -translate-x-1/2 rounded-full bg-gradient-to-b from-sky/40 to-royal dark:to-ice"
        style={{ height: top }}
      />
      <motion.div className="absolute left-1/2" style={{ top, x: wobble }}>
        <div className="absolute bottom-0 left-0 h-11 w-[7px] origin-bottom -translate-x-1/2 rotate-[14deg] sm:h-20 sm:w-3">
          <Pencil className="h-full w-full drop-shadow-[3px_6px_8px_rgba(16,42,86,0.35)]" />
        </div>
      </motion.div>
    </motion.div>
  )
}
