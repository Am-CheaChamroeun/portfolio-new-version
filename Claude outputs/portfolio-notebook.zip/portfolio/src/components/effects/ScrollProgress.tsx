import { motion, useScroll, useSpring } from 'motion/react'

/** Thin ink line across the top of the page that fills as you read. */
export function ScrollProgress() {
  const { scrollYProgress } = useScroll()
  const scaleX = useSpring(scrollYProgress, { stiffness: 120, damping: 30, restDelta: 0.001 })
  return (
    <motion.div
      className="fixed inset-x-0 top-0 z-[60] h-[2px] origin-left bg-gradient-to-r from-navy via-royal to-sky dark:from-sky dark:via-ice dark:to-sky"
      style={{ scaleX }}
    />
  )
}
