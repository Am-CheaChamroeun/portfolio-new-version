import { motion, type HTMLMotionProps } from 'motion/react'
import { easeOut } from '../../lib/motion'

type Tag = 'div' | 'h2' | 'p' | 'article' | 'span' | 'aside' | 'form'

type RevealProps = HTMLMotionProps<'div'> & {
  as?: Tag
  delay?: number
  y?: number
  x?: number
  scale?: number
  /** tilt (deg) the element starts with — gives a "paper sliding in" feel */
  tilt?: number
  duration?: number
}

/** Slides its children in like a sheet of paper once they scroll into view. */
export function Reveal({
  as = 'div',
  delay = 0,
  y = 24,
  x = 0,
  scale,
  tilt = 4,
  duration = 0.7,
  children,
  ...props
}: RevealProps) {
  const Component = motion[as] as typeof motion.div
  return (
    <Component
      initial={{ opacity: 0, y, x, rotateX: tilt, transformPerspective: 1200, ...(scale !== undefined && { scale }) }}
      whileInView={{ opacity: 1, y: 0, x: 0, rotateX: 0, ...(scale !== undefined && { scale: 1 }) }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration, delay, ease: easeOut }}
      {...props}
    >
      {children}
    </Component>
  )
}
