/** Small ink-blue pill with a pulsing dot — "Current", "Live", … */
export function StatusPill({ label }: { label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-sky/30 bg-sky/10 px-3 py-1 text-[11px] font-semibold text-primary">
      <span className="relative flex h-1.5 w-1.5">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-sky opacity-60" />
        <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-sky" />
      </span>
      {label}
    </span>
  )
}
