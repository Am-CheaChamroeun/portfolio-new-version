import { useId } from 'react'

/**
 * Hexagonal drafting pencil, tip pointing down. Viewbox 0 0 24 160 — the
 * graphite point sits at (12, 160), which is handy for cursor alignment.
 */
export function Pencil({ className = '' }: { className?: string }) {
  const id = useId().replace(/:/g, '')
  return (
    <svg viewBox="0 0 24 160" className={className} aria-hidden="true">
      <defs>
        <linearGradient id={`${id}-body`} x1="0" x2="1">
          <stop offset="0%" stopColor="#102a56" />
          <stop offset="38%" stopColor="#2354a4" />
          <stop offset="62%" stopColor="#3b82f6" />
          <stop offset="100%" stopColor="#1c4486" />
        </linearGradient>
        <linearGradient id={`${id}-metal`} x1="0" x2="1">
          <stop offset="0%" stopColor="#8a97ad" />
          <stop offset="50%" stopColor="#eef3fb" />
          <stop offset="100%" stopColor="#7d8aa1" />
        </linearGradient>
        <linearGradient id={`${id}-wood`} x1="0" x2="1">
          <stop offset="0%" stopColor="#d9b98a" />
          <stop offset="55%" stopColor="#f3dfbd" />
          <stop offset="100%" stopColor="#caa673" />
        </linearGradient>
      </defs>
      {/* eraser */}
      <rect x="3" y="0" width="18" height="16" rx="4" fill="#dcebff" />
      <rect x="3" y="10" width="18" height="6" fill="#c3d8f7" />
      {/* ferrule */}
      <rect x="2.5" y="15" width="19" height="13" fill={`url(#${id}-metal)`} />
      <path d="M2.5 19.5h19M2.5 23.5h19" stroke="#6b7890" strokeWidth="0.8" />
      {/* body */}
      <rect x="3" y="28" width="18" height="96" fill={`url(#${id}-body)`} />
      <path d="M9 28v96M15 28v96" stroke="#0b1f42" strokeOpacity="0.25" strokeWidth="0.8" />
      <text x="12" y="76" fill="#dcebff" fontSize="6" fontFamily="monospace" textAnchor="middle" transform="rotate(90 12 76)" opacity="0.7">
        HB · NOTEBOOK
      </text>
      {/* sharpened wood */}
      <path d="M3 124 L21 124 L14.2 150 L9.8 150 Z" fill={`url(#${id}-wood)`} />
      <path d="M3 124 q3 3 6 0 q3 3 6 0 q3 3 6 0" fill="none" stroke="#102a56" strokeWidth="1.2" />
      {/* graphite */}
      <path d="M9.8 150 L14.2 150 L12 160 Z" fill="#172033" />
    </svg>
  )
}
