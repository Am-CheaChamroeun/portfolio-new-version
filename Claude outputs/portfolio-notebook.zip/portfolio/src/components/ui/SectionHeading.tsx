import { motion } from 'motion/react'
import { Reveal } from './Reveal'

type Props = {
  index: string
  eyebrow: string
  title: string
  className?: string
  /** "light" = for use on the navy blueprint sections */
  tone?: 'default' | 'light'
}

/** Chapter heading: "Chapter 01 — eyebrow", serif title, pencil underline that draws in. */
export function SectionHeading({ index, eyebrow, title, className = '', tone = 'default' }: Props) {
  const light = tone === 'light'
  return (
    <div className={`mb-14 md:mb-20 ${className}`}>
      <Reveal y={16} tilt={0} className="mb-4 flex items-center gap-3">
        <span className={`font-mono text-[11px] uppercase tracking-[0.28em] ${light ? 'text-ice' : 'text-primary'}`}>
          Chapter {index}
        </span>
        <span className={`h-px w-10 ${light ? 'bg-ice/40' : 'bg-primary/40'}`} />
        <span className={`font-hand text-2xl leading-none ${light ? 'text-ice/80' : 'text-muted'}`}>{eyebrow}</span>
      </Reveal>
      <Reveal
        as="h2"
        delay={0.08}
        className={`text-balance font-display text-4xl font-medium tracking-tight md:text-6xl ${light ? 'text-paper' : 'text-fg'}`}
      >
        {title}
      </Reveal>
      <svg viewBox="0 0 240 14" className="mt-3 h-3 w-40 md:w-56" fill="none" aria-hidden="true">
        <motion.path
          d="M2 9 C 40 3, 90 12, 140 6 S 220 5, 238 8"
          className={light ? 'stroke-ice/70' : 'stroke-sky'}
          strokeWidth="3"
          strokeLinecap="round"
          initial={{ pathLength: 0 }}
          whileInView={{ pathLength: 1 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.9, delay: 0.35, ease: 'easeInOut' }}
        />
      </svg>
    </div>
  )
}
