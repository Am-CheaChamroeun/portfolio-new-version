import { Mail } from 'lucide-react'
import { motion } from 'motion/react'
import { navLinks, profile, socials } from '../../data/portfolio'
import { GithubIcon, LinkedinIcon, TelegramIcon } from '../../lib/icons'
import { Avatar } from '../ui/Avatar'

const YEAR = new Date().getFullYear()

export function Footer() {
  const links = [
    { href: `mailto:${socials.email}`, label: 'Email', icon: <Mail size={18} /> },
    { href: socials.linkedin.url, label: 'LinkedIn', icon: <LinkedinIcon size={18} /> },
    { href: socials.github.url, label: 'GitHub', icon: <GithubIcon size={18} /> },
    { href: socials.telegram.url, label: 'Telegram', icon: <TelegramIcon size={18} /> },
  ]

  return (
    <footer className="relative overflow-hidden bg-navy text-ice">
      <div className="blueprint pointer-events-none absolute inset-0 opacity-40" />
      {/* pencil line across the top */}
      <svg viewBox="0 0 1200 20" preserveAspectRatio="none" className="relative h-5 w-full" aria-hidden="true">
        <motion.path
          d="M0 10 C 150 4, 300 16, 450 9 S 750 4, 900 11 S 1100 14, 1200 8"
          className="stroke-ice/50"
          strokeWidth="1.5"
          fill="none"
          initial={{ pathLength: 0 }}
          whileInView={{ pathLength: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1.6, ease: 'easeInOut' }}
        />
      </svg>
      <div className="relative mx-auto max-w-6xl px-5 pb-14 pt-12">
        <div className="grid gap-10 md:grid-cols-3">
          <div>
            <a href="#home" className="flex items-center gap-3">
              <span className="flex rounded-full ring-1 ring-ice/40 ring-offset-2 ring-offset-navy">
                <Avatar className="h-9 w-9" />
              </span>
              <span className="font-display text-lg font-medium text-paper">
                {profile.handle}
                <span className="text-ice/70">{profile.handleSuffix}</span>
              </span>
            </a>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-ice/70">{profile.footerBlurb}</p>
            <p className="mt-3 font-hand text-xl text-ice/60">— thanks for reading.</p>
          </div>
          <div>
            <h4 className="mb-4 font-mono text-[11px] uppercase tracking-[0.25em] text-ice/50">Contents</h4>
            <ul className="grid grid-cols-2 gap-2">
              {navLinks.map((link, i) => (
                <li key={link.href}>
                  <a href={link.href} className="group inline-flex items-baseline gap-2 text-sm text-ice/80 transition-colors hover:text-paper">
                    <span className="font-mono text-[10px] text-ice/40">{String(i + 1).padStart(2, '0')}</span>
                    <span className="border-b border-transparent transition-colors group-hover:border-ice/50">{link.label}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="mb-4 font-mono text-[11px] uppercase tracking-[0.25em] text-ice/50">Correspondence</h4>
            <div className="flex gap-3">
              {links.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  aria-label={link.label}
                  {...(link.href.startsWith('http') && { target: '_blank', rel: 'noreferrer' })}
                  className="flex h-10 w-10 items-center justify-center rounded-full border border-ice/25 text-ice/80 transition-all hover:-translate-y-0.5 hover:border-ice hover:bg-ice hover:text-navy"
                >
                  {link.icon}
                </a>
              ))}
            </div>
          </div>
        </div>
        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-dashed border-ice/20 pt-6 text-xs text-ice/50 sm:flex-row">
          <p>
            © {YEAR} {profile.name}. All rights reserved.
          </p>
          <p className="font-mono">Built with Vite · React · TypeScript · Tailwind CSS</p>
        </div>
      </div>
    </footer>
  )
}
