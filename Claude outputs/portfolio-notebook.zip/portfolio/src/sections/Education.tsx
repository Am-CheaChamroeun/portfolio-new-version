import { ArrowUpRight, Calendar, GraduationCap } from 'lucide-react'
import { Reveal } from '../components/ui/Reveal'
import { SectionHeading } from '../components/ui/SectionHeading'
import { StatusPill } from '../components/ui/StatusPill'
import { education, type EducationItem } from '../data/portfolio'

function ChapterCard({ item }: { item: EducationItem }) {
  const cls =
    'group ruled dog-ear relative block rounded-r-xl rounded-l-sm border border-card-border bg-sheet py-6 pl-16 pr-8 shadow-paper transition-all duration-300 [--ear-bg:var(--bg-subtle)] [--line:2rem] [--margin:2.75rem] hover:-translate-y-1 hover:rotate-[-0.35deg] hover:[--ear:36px] hover:shadow-[0_28px_50px_-24px_rgba(16,42,86,0.45)]'
  const body = (
    <>
      {item.url && (
        <span className="absolute right-10 top-4 z-10 inline-flex items-center gap-1 rounded-full border border-card-border bg-bg-subtle px-2.5 py-1 text-[10px] font-medium text-primary opacity-0 transition-all duration-300 group-hover:opacity-100">
          Visit site
          <ArrowUpRight size={11} />
        </span>
      )}
      <div className="mb-3 flex flex-wrap items-center gap-3">
        <div className="relative flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-lg border border-card-border bg-white">
          {item.logo ? (
            <img src={item.logo} alt={`${item.school} logo`} className="h-full w-full object-contain p-1.5" />
          ) : (
            <GraduationCap size={22} strokeWidth={1.6} className="text-royal" />
          )}
        </div>
        <span className="inline-flex items-center gap-1.5 rounded-full border border-card-border bg-bg-subtle px-3 py-1 font-mono text-[11px] text-muted">
          <Calendar size={12} />
          {item.period}
        </span>
        {item.current && <StatusPill label="Current" />}
      </div>
      <h3 className="font-display text-xl font-medium leading-8 text-fg transition-colors group-hover:text-primary md:text-2xl md:leading-[2.5rem]">
        {item.school}
      </h3>
      <ul>
        {item.details.map((d, i) => (
          <li key={i} className="flex items-start gap-3 text-[15px] leading-8 text-muted">
            <span className="font-hand text-xl leading-8 text-sky">—</span>
            <span>{d}</span>
          </li>
        ))}
      </ul>
    </>
  )

  return item.url ? (
    <a href={item.url} target="_blank" rel="noreferrer" aria-label={`${item.school} — visit website`} className={cls}>
      {body}
    </a>
  ) : (
    <div className={cls}>{body}</div>
  )
}

export function Education() {
  return (
    <section id="education" className="relative bg-bg-subtle py-24 md:py-32">
      <div className="grid-bg pointer-events-none absolute inset-0 opacity-60 [mask-image:linear-gradient(to_bottom,black,transparent_70%)]" />
      <div className="relative mx-auto max-w-6xl px-5">
        <SectionHeading index="02" eyebrow="Academic background" title="Education" />
        <div className="relative">
          {/* chapter spine */}
          <div className="absolute bottom-4 left-[19px] top-4 w-px bg-[repeating-linear-gradient(to_bottom,var(--border-strong)_0_4px,transparent_4px_9px)] md:left-[150px]" />
          <div className="space-y-10">
            {education.map((item, i) => (
              <Reveal key={i} y={30} className="relative grid gap-4 md:grid-cols-[150px_1fr] md:gap-12">
                <span className="absolute left-[12px] top-7 z-10 flex h-4 w-4 items-center justify-center rounded-full border-2 border-royal bg-bg-subtle md:left-[143px] dark:border-sky">
                  {item.current && <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-sky opacity-40" />}
                  <span className="relative h-1.5 w-1.5 rounded-full bg-royal dark:bg-sky" />
                </span>
                <div className="pl-12 md:pl-0 md:pr-8 md:text-right">
                  <div className="font-mono text-[10px] uppercase tracking-[0.25em] text-faint">Ch. 2.{i + 1}</div>
                  <div className="font-display text-5xl font-light leading-none text-transparent [-webkit-text-stroke:1px_var(--primary)] md:text-7xl">
                    {String(i + 1).padStart(2, '0')}
                  </div>
                </div>
                <div className="pl-12 md:pl-0">
                  <ChapterCard item={item} />
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
