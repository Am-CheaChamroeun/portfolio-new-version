import { ChevronLeft, ChevronRight } from 'lucide-react'
import { AnimatePresence, motion } from 'motion/react'
import { useState } from 'react'
import { Reveal } from '../components/ui/Reveal'
import { SectionHeading } from '../components/ui/SectionHeading'
import { about } from '../data/portfolio'
import { useInterval } from '../hooks/useInterval'
import { TechIcon } from '../lib/icons'
import { techIcons, type TechKey } from '../lib/tech'

const TODAY = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })
const tools: TechKey[] = [...about.orbitInner, ...about.orbitOuter]

/** A small sketchbook that turns its pages on its own — one tool per page. */
function ToolboxFlip() {
  const [index, setIndex] = useState(0)
  const [paused, setPaused] = useState(false)
  useInterval(() => setIndex((i) => (i + 1) % tools.length), paused ? null : 2600)
  const go = (i: number) => setIndex((i + tools.length) % tools.length)
  const key = tools[index]

  return (
    <div onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)} className="w-full">
      <div className="mb-3 flex items-end justify-between">
        <span className="font-hand text-2xl leading-none text-fg">My toolbox</span>
        <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-faint">
          page {String(index + 1).padStart(2, '0')} / {String(tools.length).padStart(2, '0')}
        </span>
      </div>

      <div className="relative mx-auto aspect-[4/3] w-full" style={{ perspective: 1400 }}>
        {/* the book's back pages */}
        <div className="absolute inset-0 translate-x-1.5 translate-y-1.5 rounded-r-xl rounded-l-sm border border-card-border bg-bg-subtle" />
        <div className="absolute inset-y-0 left-0 z-20 w-3 rounded-l-sm bg-gradient-to-r from-navy/25 to-transparent" />
        <AnimatePresence initial={false}>
          <motion.button
            key={key}
            type="button"
            onClick={() => go(index + 1)}
            aria-label={`${techIcons[key].title} — turn the page`}
            className="grid-bg absolute inset-0 flex origin-left flex-col items-center justify-center rounded-r-xl rounded-l-sm border border-card-border bg-sheet shadow-paper [backface-visibility:hidden]"
            style={{ zIndex: 1 }}
            initial={{ rotateY: 0 }}
            exit={{ rotateY: -150, opacity: 0.4, zIndex: 2, transition: { duration: 0.75, ease: [0.65, 0, 0.35, 1] } }}
          >
            <span className="flex h-20 w-20 items-center justify-center rounded-2xl border border-card-border bg-white shadow-sm">
              <TechIcon name={key} size={44} />
            </span>
            <span className="mt-4 font-display text-2xl font-medium text-fg">{techIcons[key].title}</span>
            <span className="mt-1 font-hand text-lg text-faint">fig. {String(index + 1).padStart(2, '0')}</span>
            <span className="absolute bottom-3 right-4 font-mono text-[10px] text-faint">→ click to turn</span>
          </motion.button>
        </AnimatePresence>
      </div>

      {/* index tabs: every tool, with a tooltip */}
      <div className="mt-5 flex items-center gap-2">
        <button type="button" onClick={() => go(index - 1)} aria-label="Previous page" className="text-faint transition-colors hover:text-primary">
          <ChevronLeft size={18} />
        </button>
        <div className="flex flex-1 flex-wrap justify-center gap-1.5">
          {tools.map((t, i) => (
            <button
              key={t}
              type="button"
              onClick={() => go(i)}
              aria-label={techIcons[t].title}
              className={`group/tile relative flex h-9 w-9 items-center justify-center rounded-md border bg-white transition-all hover:-translate-y-0.5 ${
                i === index ? 'border-royal shadow-[0_0_0_3px_var(--primary-glow)] dark:border-sky' : 'border-card-border'
              }`}
            >
              <TechIcon name={t} size={18} />
              <span className="pointer-events-none absolute left-1/2 top-full z-10 mt-2 -translate-x-1/2 whitespace-nowrap rounded border border-card-border bg-sheet px-2 py-0.5 text-[10px] font-medium text-muted opacity-0 shadow-paper transition-opacity group-hover/tile:opacity-100">
                {techIcons[t].title}
              </span>
            </button>
          ))}
        </div>
        <button type="button" onClick={() => go(index + 1)} aria-label="Next page" className="text-faint transition-colors hover:text-primary">
          <ChevronRight size={18} />
        </button>
      </div>
    </div>
  )
}

export function About() {
  return (
    <section id="about" className="relative mx-auto max-w-6xl px-5 py-24 md:py-32">
      <SectionHeading index="01" eyebrow="Who I am" title="About Me" />

      <div className="grid gap-12 lg:grid-cols-[1.35fr_1fr] lg:gap-14">
        {/* journal page */}
        <Reveal className="relative">
          <div className="ruled paper-grain dog-ear relative rounded-r-2xl rounded-l-md border border-card-border bg-sheet px-6 pb-8 pl-[4.25rem] pt-6 shadow-paper [--line:2rem] [--margin:3.25rem] sm:pr-10">
            <div className="flex h-8 items-center justify-between">
              <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-faint">Journal · {TODAY}</span>
            </div>
            <p className="h-8 font-hand text-2xl leading-8 text-primary">Dear reader,</p>
            <div className="mt-8 space-y-8">
              {about.paragraphs.map((text, i) => (
                <Reveal key={i} as="p" y={14} tilt={0} delay={0.1 + i * 0.1} className="relative text-[16.5px] leading-8 text-muted">
                  <span className="absolute -left-12 top-0 w-8 text-right font-hand text-xl leading-8 text-sky/80">{i + 1}.</span>
                  {text}
                </Reveal>
              ))}
            </div>
            <div className="mt-8">
              <p className="h-8 font-hand text-xl leading-8 text-faint">notes to self —</p>
              <div className="flex flex-wrap gap-2 pt-1">
                {about.chips.map((chip, i) => (
                  <span
                    key={chip}
                    className={`rounded-sm border border-dashed border-primary/40 bg-bg-subtle px-3 py-1 font-mono text-xs text-primary ${
                      i % 2 ? 'rotate-[0.8deg]' : 'rotate-[-0.8deg]'
                    }`}
                  >
                    {chip}
                  </span>
                ))}
              </div>
            </div>
            <span className="absolute -bottom-4 right-6 rotate-[-4deg] font-hand text-xl text-faint">keep learning, keep shipping ✎</span>
          </div>
        </Reveal>

        <Reveal x={24} y={0} delay={0.15} className="flex flex-col gap-8">
          <ToolboxFlip />
          <div className="grid w-full grid-cols-2 gap-3">
            {about.features.map(({ icon: Icon, label }, i) => (
              <Reveal
                key={label}
                y={0}
                scale={0.94}
                delay={0.2 + i * 0.08}
                className="group relative overflow-hidden rounded-md border border-card-border bg-sheet p-4 pt-5 shadow-paper transition-transform hover:-translate-y-1 hover:rotate-[-0.6deg]"
              >
                <span className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-royal to-sky" />
                <span className="flex items-center gap-3">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-dashed border-primary/50 text-primary transition-transform group-hover:rotate-12">
                    <Icon size={17} strokeWidth={1.6} />
                  </span>
                  <span className="text-sm font-medium text-fg">{label}</span>
                </span>
              </Reveal>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  )
}
