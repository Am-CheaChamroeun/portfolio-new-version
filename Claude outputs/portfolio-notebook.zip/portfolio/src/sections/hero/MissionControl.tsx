import { Activity, Compass, Feather, MapPin, PenLine, type LucideIcon } from 'lucide-react'
import { useState } from 'react'
import { Globe } from '../../components/effects/Globe'
import { heroTelemetry, profile } from '../../data/portfolio'
import { useInterval } from '../../hooks/useInterval'

function Row({ icon: Icon, label, value, bar }: { icon: LucideIcon; label: string; value: string; bar?: number }) {
  return (
    <div className="text-[11px] leading-tight">
      <div className="flex items-center justify-between gap-3">
        <span className="inline-flex items-center gap-1.5 font-mono text-[9.5px] uppercase tracking-wider text-faint">
          <Icon size={12} className="text-primary" />
          {label}
        </span>
        <span className="font-mono text-[10px] text-fg">{value}</span>
      </div>
      {bar !== undefined && (
        <div className="mt-1.5 h-[3px] rounded-full bg-[repeating-linear-gradient(90deg,var(--border)_0_3px,transparent_3px_5px)]">
          <div className="h-full rounded-full bg-royal transition-[width] duration-700 dark:bg-sky" style={{ width: `${bar}%` }} />
        </div>
      )}
    </div>
  )
}

const wander = (v: number, min: number, max: number) => Math.max(min, Math.min(max, v + (Math.random() - 0.5) * 12))

/** Left hero card: "field notes" — a sketched globe and today's live log. */
export function MissionControl() {
  const [focus, setFocus] = useState(72)
  const [flow, setFlow] = useState(88)
  useInterval(() => {
    setFocus((v) => wander(v, 48, 96))
    setFlow((v) => wander(v, 70, 99))
  }, 1600)

  return (
    <div className="relative rotate-[-1deg] rounded-lg border border-card-border bg-sheet p-4 shadow-[0_24px_50px_-24px_rgba(4,14,36,0.75)]">
      {/* tape */}
      <span className="absolute -top-2.5 left-1/2 h-5 w-20 -translate-x-1/2 rotate-2 bg-sky/25 backdrop-blur-[1px]" aria-hidden="true" />
      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <span className="font-hand text-xl leading-none text-fg">Field notes</span>
          <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-primary">today</span>
        </div>
        <div className="grid-bg relative h-40 overflow-hidden rounded-md border border-card-border bg-bg-subtle">
          <Globe marker={profile.globeMarker} />
          <div className="absolute bottom-2 left-1/2 inline-flex -translate-x-1/2 items-center gap-1 whitespace-nowrap rounded-full border border-card-border bg-sheet/90 px-2.5 py-0.5 font-hand text-[15px] leading-tight text-primary">
            <MapPin size={11} />
            {profile.locationFlag} {profile.location}
          </div>
        </div>
        <Row icon={PenLine} label="Focus" value={`${Math.round(focus)}%`} bar={focus} />
        <Row icon={Feather} label="Flow" value={`${Math.round(flow)}%`} bar={flow} />
        <Row icon={Activity} label="Uptime" value={heroTelemetry.uptime} bar={99} />
        <Row icon={Compass} label="Region" value={heroTelemetry.region} />
        <div className="flex items-center justify-between border-t border-dashed border-card-border pt-2.5">
          <span className="font-mono text-[9.5px] uppercase tracking-wider text-faint">Status</span>
          <span className="rotate-[-3deg] rounded border-2 border-primary/70 px-1.5 font-mono text-[9px] font-bold uppercase tracking-widest text-primary">
            {heroTelemetry.status}
          </span>
        </div>
      </div>
    </div>
  )
}
