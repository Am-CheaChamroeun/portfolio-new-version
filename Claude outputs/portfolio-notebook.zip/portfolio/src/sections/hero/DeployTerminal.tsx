import { useEffect, useState } from 'react'
import { heroTelemetry, terminalLines } from '../../data/portfolio'

const TYPE_MS = 35
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))

type Shown = { cmd: string; out?: string; tone?: 'success' | 'info'; typing: boolean }

/** Right hero card: a blueprint spec sheet on which the deploy steps are drafted, on a loop. */
export function DeployTerminal({ start }: { start: boolean }) {
  const [lines, setLines] = useState<Shown[]>(() => terminalLines.map((l) => ({ ...l, typing: false })))

  useEffect(() => {
    if (!start) return
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    let cancelled = false
    const run = async () => {
      await sleep(400)
      while (!cancelled) {
        const shown: Shown[] = []
        for (const line of terminalLines) {
          shown.push({ cmd: '', typing: true })
          for (let i = 1; i <= line.cmd.length && !cancelled; i++) {
            shown[shown.length - 1] = { cmd: line.cmd.slice(0, i), typing: true }
            setLines([...shown])
            await sleep(TYPE_MS)
          }
          await sleep(450)
          shown[shown.length - 1] = { ...line, typing: false }
          setLines([...shown])
          await sleep(line.out ? 900 : 300)
          if (cancelled) return
        }
        await sleep(2600)
      }
    }
    run()
    return () => {
      cancelled = true
    }
  }, [start])

  return (
    <>
      <div className="blueprint relative rotate-[1deg] overflow-hidden rounded-md border border-ice/25 font-mono text-[10.5px] leading-relaxed text-ice shadow-[0_24px_50px_-24px_rgba(4,14,36,0.85)]">
        <div className="flex items-center justify-between border-b border-ice/20 px-3 py-1.5">
          <span className="text-[9px] uppercase tracking-[0.22em] text-ice/70">Blueprint · deploy.sh</span>
          <span className="inline-flex items-center gap-1 text-[9px] text-ice/70">
            <span className="h-1 w-1 animate-pulse rounded-full bg-sky" />
            drafting
          </span>
        </div>
        <div className="min-h-[150px] space-y-1 p-3">
          {lines.map((line, i) => (
            <div key={i}>
              <div className="flex items-start gap-1.5">
                <span className="text-sky">{String(i + 1).padStart(2, '0')}</span>
                <span className="break-all text-paper/90">
                  {line.cmd}
                  {line.typing && <span className="cursor-blink">▍</span>}
                </span>
              </div>
              {line.out && (
                <div className={`pl-5 font-hand text-[15px] leading-snug ${line.tone === 'info' ? 'text-sky' : 'text-ice'}`}>{line.out}</div>
              )}
            </div>
          ))}
        </div>
        {/* engineering title block */}
        <div className="grid grid-cols-3 border-t border-ice/20 text-[8px] uppercase tracking-wider text-ice/60">
          <span className="border-r border-ice/20 px-2 py-1">Scale 1:1</span>
          <span className="border-r border-ice/20 px-2 py-1">Rev. A</span>
          <span className="px-2 py-1">Sheet 01</span>
        </div>
      </div>
      <div className="mt-4 grid grid-cols-2 gap-2.5">
        {[
          { label: 'Deploys', value: heroTelemetry.deploys },
          { label: 'Uptime', value: heroTelemetry.uptime },
        ].map((s, i) => (
          <div
            key={s.label}
            className={`rounded-sm border border-card-border bg-sheet px-2.5 py-2 shadow-[0_12px_24px_-16px_rgba(4,14,36,0.8)] ${
              i ? 'rotate-[1.5deg]' : 'rotate-[-1.5deg]'
            }`}
          >
            <div className="font-mono text-[9px] uppercase tracking-wider text-faint">{s.label}</div>
            <div className="mt-0.5 font-display text-lg font-medium text-primary">{s.value}</div>
          </div>
        ))}
      </div>
    </>
  )
}
