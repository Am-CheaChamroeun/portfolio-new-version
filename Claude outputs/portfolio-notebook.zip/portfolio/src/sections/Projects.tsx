import { ArrowUpRight, Globe, Paperclip, Sparkles } from 'lucide-react'
import { Reveal } from '../components/ui/Reveal'
import { SectionHeading } from '../components/ui/SectionHeading'
import { StatusPill } from '../components/ui/StatusPill'
import { featuredProject, projects, socials, type Project } from '../data/portfolio'
import { GithubIcon } from '../lib/icons'

const alpha = (hex: string, a: number) =>
  `${hex}${Math.round(a * 255)
    .toString(16)
    .padStart(2, '0')}`

const displayUrl = (p: Project) =>
  (p.liveUrl || p.repoUrl || `github.com/${socials.github.label.replace('@', '')}/${p.slug}`).replace(/^https?:\/\//, '')

/** Preview "pinned" to the page: a sketched browser frame holding the screenshot, or a wireframe. */
function Preview({ project, className, large = false }: { project: Project; className: string; large?: boolean }) {
  const { accent } = project
  return (
    <div className={`relative overflow-hidden rounded-md border border-card-border bg-bg-elevated ${className}`}>
      <div className="grid-bg absolute inset-0" style={{ backgroundColor: alpha(accent, 0.05) }} />
      <div className="relative flex items-center gap-2 border-b border-card-border bg-sheet/80 px-3 py-2">
        {[0, 1, 2].map((i) => (
          <span key={i} className="h-2.5 w-2.5 rounded-full border border-faint/60" />
        ))}
        <div className="mx-auto max-w-[70%] truncate rounded-sm border border-dashed border-card-border px-3 py-0.5 font-mono text-[10px] text-faint">
          {displayUrl(project)}
        </div>
      </div>
      <div className="relative h-[calc(100%-2.25rem)] overflow-hidden">
        {project.image ? (
          <img
            src={project.image}
            alt={`${project.name} preview`}
            className={`absolute inset-0 h-full w-full transition-transform duration-700 group-hover:scale-105 ${
              project.imageFit === 'contain' ? `object-contain ${large ? 'p-10' : 'p-6'}` : 'object-cover object-top'
            }`}
          />
        ) : (
          <>
            {/* pencil wireframe in the project's accent colour */}
            <svg viewBox="0 0 200 120" preserveAspectRatio="none" className="absolute inset-0 h-full w-full opacity-60" fill="none" aria-hidden="true">
              <g stroke={accent} strokeWidth="1" strokeLinecap="round" vectorEffect="non-scaling-stroke">
                <path d="M16 18 C 60 17, 120 19, 184 18" vectorEffect="non-scaling-stroke" />
                <path d="M16 34 L 96 33 L 97 92 L 17 93 Z" vectorEffect="non-scaling-stroke" />
                <path d="M110 36 C 140 35, 160 37, 182 36 M110 50 C 135 49, 150 51, 170 50 M110 64 C 130 63, 145 65, 160 64" vectorEffect="non-scaling-stroke" />
                <path d="M110 78 L 150 77 L 150 92 L 110 92 Z" vectorEffect="non-scaling-stroke" />
              </g>
            </svg>
            <div className="relative flex h-full items-center justify-center">
              <div
                className={`font-display font-medium italic transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-110 ${
                  large ? 'text-8xl' : 'text-5xl'
                }`}
                style={{ color: accent }}
              >
                {project.name.replace(/[^A-Za-z]/g, '').charAt(0) || 'P'}
              </div>
            </div>
          </>
        )}
        <span className="pointer-events-none absolute bottom-2 left-3 font-hand text-[15px] text-faint">~/{project.slug}</span>
      </div>
    </div>
  )
}

function Status({ project }: { project: Project }) {
  return project.liveUrl ? (
    <StatusPill label="Live" />
  ) : (
    <span className="inline-flex items-center gap-1 text-[11px] font-medium text-faint">
      <span className="h-1.5 w-1.5 rounded-full bg-faint" />
      Repo only
    </span>
  )
}

const Tags = ({ items, small = false }: { items: string[]; small?: boolean }) => (
  <div className="flex flex-wrap gap-1.5">
    {items.map((t) => (
      <span key={t} className={`rounded-full border border-card-border px-2.5 py-1 font-mono text-muted ${small ? 'text-[10.5px]' : 'text-[11px]'}`}>
        {t}
      </span>
    ))}
  </div>
)

const Highlights = ({ items, small = false }: { items: string[]; small?: boolean }) => (
  <ul className="space-y-0">
    {items.map((h, i) => (
      <li key={i} className={`flex gap-2 leading-8 text-muted ${small ? 'text-[13px]' : 'text-sm'}`}>
        <span className="font-hand text-lg text-sky">✓</span>
        {h}
      </li>
    ))}
  </ul>
)

/** The featured case study as an open notebook spread. */
function Featured({ project }: { project: Project }) {
  return (
    <Reveal as="article" y={32} className="group relative">
      <div className="absolute inset-x-4 -bottom-2 top-2 rounded-2xl bg-ice/60 dark:bg-ice/10" />
      <div className="relative grid overflow-hidden rounded-2xl border border-card-border bg-sheet shadow-paper lg:grid-cols-2">
        {/* centre spine */}
        <div className="pointer-events-none absolute inset-y-0 left-1/2 hidden w-16 -translate-x-1/2 bg-[linear-gradient(90deg,transparent,rgba(16,42,86,0.08)_45%,rgba(16,42,86,0.16)_50%,rgba(16,42,86,0.08)_55%,transparent)] lg:block" />

        <div className="ruled relative px-6 py-8 pl-16 [--line:2rem] [--margin:2.75rem] md:py-10 md:pr-12">
          <div className="mb-4 flex h-8 flex-wrap items-center gap-2">
            <span
              className="inline-flex items-center gap-1.5 rounded-full px-3 py-1 font-mono text-[10px] font-semibold uppercase tracking-wider"
              style={{ background: alpha(project.accent, 0.12), color: project.accent }}
            >
              <Sparkles size={12} />
              Featured · Case study 00
            </span>
            <Status project={project} />
          </div>
          <h3 className="font-display text-3xl font-medium leading-[2.5rem] tracking-tight md:text-4xl md:leading-[3rem]">{project.name}</h3>
          {project.tagline && <p className="font-hand text-2xl leading-8 text-primary">{project.tagline}</p>}
          <p className="mt-4 text-[15px] leading-8 text-muted">{project.description}</p>
          <div className="mt-4">
            <Highlights items={project.highlights} />
          </div>
          <div className="mt-5">
            <Tags items={project.tech} />
          </div>
          <div className="mt-7 flex flex-wrap gap-3">
            {project.liveUrl && (
              <a
                href={project.liveUrl}
                target="_blank"
                rel="noreferrer"
                className="group/btn inline-flex items-center gap-2 rounded-full bg-royal px-5 py-2.5 text-sm font-semibold text-paper transition-all hover:-translate-y-0.5 hover:bg-navy dark:bg-sky dark:hover:bg-royal"
              >
                <Globe size={16} />
                Visit Live
                <ArrowUpRight size={16} className="transition-transform group-hover/btn:-translate-y-0.5 group-hover/btn:translate-x-0.5" />
              </a>
            )}
            <a
              href={project.repoUrl || socials.github.url}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-full border border-card-border bg-sheet px-5 py-2.5 text-sm font-semibold transition-all hover:-translate-y-0.5 hover:border-primary hover:text-primary"
            >
              <GithubIcon size={16} />
              View Repo
            </a>
          </div>
        </div>

        <div className="grid-bg relative p-6 md:p-10">
          <div className="relative h-full min-h-[300px] rotate-[1.2deg] transition-transform duration-500 group-hover:rotate-0">
            <Paperclip size={34} strokeWidth={1.3} className="absolute -top-5 left-8 z-10 rotate-[18deg] text-faint" aria-hidden="true" />
            <Preview project={project} large className="h-full min-h-[300px] shadow-paper" />
          </div>
        </div>
      </div>
    </Reveal>
  )
}

/** A loose notebook page: binder holes, a folded corner that lifts, a slight page-turn on hover. */
function Card({ project, index }: { project: Project; index: number }) {
  return (
    <Reveal as="article" y={28} delay={index * 0.08} className="group relative [perspective:1400px]">
      <div className="absolute inset-0 translate-x-1.5 translate-y-1.5 rounded-r-xl rounded-l-sm border border-card-border bg-bg-elevated/70" />
      <div className="dog-ear relative flex h-full origin-left flex-col rounded-r-xl rounded-l-sm border border-card-border bg-sheet shadow-paper transition-all duration-500 [--ear-bg:var(--bg-subtle)] group-hover:-translate-y-2 group-hover:[--ear:42px] group-hover:[transform:rotateY(-5deg)] group-hover:shadow-[0_30px_50px_-24px_rgba(16,42,86,0.5)]">
        {/* binder holes */}
        <div className="absolute inset-y-0 left-2 flex flex-col justify-around py-10" aria-hidden="true">
          {[0, 1, 2].map((i) => (
            <span key={i} className="h-3 w-3 rounded-full border border-card-border bg-bg-subtle shadow-inner" />
          ))}
        </div>
        <div className="flex flex-1 flex-col py-5 pl-9 pr-5">
          <div className="mb-3 flex items-center justify-between">
            <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-faint">Case study {String(index + 1).padStart(2, '0')}</span>
          </div>
          <Preview project={project} className="h-40" />
          <div className="mt-5 flex items-start justify-between gap-3">
            <div>
              <h3 className="font-display text-xl font-medium leading-tight transition-colors group-hover:text-primary">{project.name}</h3>
              <div className="mt-1.5">
                <Status project={project} />
              </div>
            </div>
            <ArrowUpRight
              size={20}
              className="shrink-0 text-faint transition-all group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-primary"
            />
          </div>
          <p className="mt-3 text-sm leading-relaxed text-muted">{project.description}</p>
          <div className="mt-2">
            <Highlights items={project.highlights} small />
          </div>
          <div className="mt-auto space-y-4 pt-4">
            <Tags items={project.tech} small />
            <div className="flex gap-2 border-t border-dashed border-card-border pt-4">
              {project.liveUrl && (
                <a
                  href={project.liveUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-full bg-royal px-3 py-2 text-xs font-semibold text-paper transition-colors hover:bg-navy dark:bg-sky"
                >
                  <Globe size={14} />
                  Live
                </a>
              )}
              <a
                href={project.repoUrl || socials.github.url}
                target="_blank"
                rel="noreferrer"
                className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-full border border-card-border px-3 py-2 text-xs font-semibold transition-colors hover:border-primary hover:text-primary"
              >
                <GithubIcon size={14} />
                Repo
              </a>
            </div>
          </div>
        </div>
      </div>
    </Reveal>
  )
}

export function Projects() {
  return (
    <section id="projects" className="relative bg-bg-subtle py-24 md:py-32">
      <div className="grid-bg pointer-events-none absolute inset-0 opacity-60 [mask-image:linear-gradient(to_bottom,black,transparent_60%)]" />
      <div className="relative mx-auto max-w-6xl px-5">
        <SectionHeading index="05" eyebrow="Selected work" title="Featured Projects" />
        <div className="space-y-12">
          <Featured project={featuredProject} />
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {projects.map((p, i) => (
              <Card key={p.slug} project={p} index={i} />
            ))}
          </div>
          <Reveal y={16} tilt={0} className="flex justify-center pt-2">
            <a
              href={socials.github.url}
              target="_blank"
              rel="noreferrer"
              className="group inline-flex items-center gap-2 rounded-full border border-card-border bg-sheet px-5 py-2.5 text-sm font-medium text-muted shadow-paper transition-all hover:-translate-y-0.5 hover:border-primary hover:text-primary"
            >
              <GithubIcon size={16} />
              See more on GitHub
              <ArrowUpRight size={16} className="transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </a>
          </Reveal>
        </div>
      </div>
    </section>
  )
}
