import { Reveal } from '../components/ui/Reveal'
import { SectionHeading } from '../components/ui/SectionHeading'
import { highlightedServices, services } from '../data/portfolio'

const words = ['Zero', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve']

/** Small registration cross used at the corners of each drawing. */
const Cross = ({ className }: { className: string }) => (
  <svg viewBox="0 0 12 12" className={`absolute h-3 w-3 text-ice/50 ${className}`} aria-hidden="true">
    <path d="M6 0v12M0 6h12" stroke="currentColor" strokeWidth="1" />
  </svg>
)

export function Services() {
  return (
    <section id="services" className="relative overflow-hidden bg-navy py-24 text-paper md:py-32 dark:bg-[#071631]">
      <div className="blueprint pointer-events-none absolute inset-0 opacity-80" />
      <div className="relative mx-auto max-w-6xl px-5">
        <SectionHeading index="06" eyebrow="How I can help" title="Specializations" tone="light" />
        <Reveal as="p" y={0} tilt={0} className="-mt-8 mb-12 max-w-md font-mono text-[11px] uppercase tracking-[0.18em] text-ice/60">
          {words[services.length] ?? services.length} practices · ordered by frequency in shipped work.
        </Reveal>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s, i) => {
            const hot = i < highlightedServices
            const Icon = s.icon
            const num = String(i + 1).padStart(2, '0')
            return (
              <Reveal
                key={s.title}
                as="article"
                y={28}
                delay={(i % 3) * 0.08}
                className={`group relative flex h-full min-h-[340px] flex-col border p-7 transition-colors duration-300 lg:p-8 ${
                  hot ? 'border-ice/45 bg-ice/[0.05]' : 'border-ice/15 hover:border-ice/40 hover:bg-ice/[0.03]'
                }`}
              >
                <Cross className="-left-1.5 -top-1.5" />
                <Cross className="-right-1.5 -top-1.5" />
                <Cross className="-bottom-1.5 -left-1.5" />
                <Cross className="-bottom-1.5 -right-1.5" />

                {/* dimension line */}
                <div className="flex items-center gap-2 font-mono text-[9px] uppercase tracking-[0.2em] text-ice/45">
                  <span className="h-2 w-px bg-ice/40" />
                  <span className="h-px flex-1 bg-ice/25" />
                  <span>Fig. {num}</span>
                  <span className="h-px flex-1 bg-ice/25" />
                  <span className="h-2 w-px bg-ice/40" />
                </div>

                <div className="mt-6 flex items-start justify-between">
                  <span
                    className={`font-display text-[64px] font-light leading-[0.85] tracking-tight transition-colors duration-300 lg:text-[80px] ${
                      hot ? 'text-paper' : 'text-transparent [-webkit-text-stroke:1px_rgba(220,235,255,0.55)] group-hover:text-ice/25'
                    }`}
                  >
                    {num}
                  </span>
                  <span className="flex h-12 w-12 items-center justify-center rounded-full border border-dashed border-ice/40 text-ice transition-transform duration-500 group-hover:rotate-[20deg]">
                    <Icon size={20} strokeWidth={1.3} />
                  </span>
                </div>

                <h3 className="mt-8 font-display text-2xl font-medium tracking-tight text-paper">{s.title}</h3>
                <p className="mt-3 max-w-[34ch] text-sm leading-relaxed text-ice/70">{s.description}</p>
                <div className="mt-auto pt-8">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[10px] uppercase tracking-[0.22em] text-ice/50">Spec</span>
                    <div className="h-px flex-1 border-b border-dashed border-ice/25" />
                  </div>
                  <p className="mt-2.5 font-mono text-[11px] leading-relaxed text-ice/80">{s.stack}</p>
                </div>
              </Reveal>
            )
          })}
        </div>
        <Reveal as="p" y={0} tilt={0} className="mt-14 text-center font-hand text-2xl text-ice/70">
          Have a project that doesn't fit a box?{' '}
          <a href="#contact" className="text-paper underline decoration-sky decoration-wavy underline-offset-4 hover:decoration-ice">
            Let's talk
          </a>
        </Reveal>
      </div>
    </section>
  )
}
