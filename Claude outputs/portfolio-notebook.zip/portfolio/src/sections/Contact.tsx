import { ArrowUpRight, CheckCircle2, Download, Mail, Send } from 'lucide-react'
import { useState, type FormEvent, type FormEventHandler, type ReactNode } from 'react'
import { Reveal } from '../components/ui/Reveal'
import { SectionHeading } from '../components/ui/SectionHeading'
import { contactFormEndpoint, profile, socials } from '../data/portfolio'
import { GithubIcon, LinkedinIcon, TelegramIcon } from '../lib/icons'

type Status = 'idle' | 'sending' | 'sent' | 'error'

const inputCls =
  'w-full border-0 border-b-2 border-dashed border-line bg-transparent px-0 py-2 text-[15px] text-fg outline-none transition-colors placeholder:text-faint focus:border-solid focus:border-primary'
const labelCls = 'block font-hand text-xl leading-none text-primary'

function ContactLink({ href, icon, label, value }: { href: string; icon: ReactNode; label: string; value: string }) {
  const external = href.startsWith('http')
  return (
    <a
      href={href}
      {...(external && { target: '_blank', rel: 'noreferrer' })}
      className="group flex items-center gap-4 border-b border-dashed border-card-border py-3.5 transition-colors"
    >
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-card-border bg-sheet text-primary transition-all group-hover:-rotate-6 group-hover:border-primary">
        {icon}
      </span>
      <div className="min-w-0 flex-1">
        <div className="font-display text-base font-medium">{label}</div>
        <div className="truncate font-mono text-xs text-faint">{value}</div>
      </div>
      <ArrowUpRight size={18} className="shrink-0 text-faint transition-all group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-primary" />
    </a>
  )
}

export function Contact() {
  const [status, setStatus] = useState<Status>('idle')

  const onSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const data = Object.fromEntries(new FormData(form)) as Record<string, string>
    if (!contactFormEndpoint) {
      // No backend configured: hand the message to the visitor's email app.
      const subject = encodeURIComponent(`Portfolio enquiry from ${data.name}`)
      const body = encodeURIComponent(`${data.message}\n\n— ${data.name} (${data.email})`)
      window.location.href = `mailto:${socials.email}?subject=${subject}&body=${body}`
      setStatus('sent')
      return
    }
    setStatus('sending')
    try {
      const res = await fetch(contactFormEndpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(data),
      })
      if (!res.ok) throw new Error(String(res.status))
      form.reset()
      setStatus('sent')
    } catch {
      setStatus('error')
    }
  }

  return (
    <section id="contact" className="mx-auto max-w-6xl px-5 py-24 md:py-32">
      <SectionHeading index="07" eyebrow="Let's connect" title="Write the Next Chapter." />
      <div className="grid gap-12 lg:grid-cols-[1fr_1.2fr] lg:gap-16">
        <Reveal x={-24} y={0} className="space-y-7">
          <p className="text-base leading-8 text-muted md:text-lg">{profile.availability}</p>
          <div>
            <p className="mb-1 font-mono text-[10px] uppercase tracking-[0.25em] text-faint">Address book</p>
            <ContactLink href={`mailto:${socials.email}`} icon={<Mail size={18} />} label="Email" value={socials.email} />
            <ContactLink href={socials.linkedin.url} icon={<LinkedinIcon size={18} />} label="LinkedIn" value={socials.linkedin.label} />
            <ContactLink href={socials.github.url} icon={<GithubIcon size={18} />} label="GitHub" value={socials.github.label} />
            <ContactLink href={socials.telegram.url} icon={<TelegramIcon size={18} />} label="Telegram" value={socials.telegram.label} />
          </div>
          {profile.cvUrl && (
            <a
              href={profile.cvUrl}
              className="inline-flex items-center gap-2 rounded-full border border-card-border bg-sheet px-6 py-3 text-sm font-semibold shadow-paper transition-all hover:-translate-y-0.5 hover:border-primary hover:text-primary"
            >
              <Download size={16} />
              Download CV
            </a>
          )}
        </Reveal>

        <Reveal
          as="form"
          x={24}
          y={0}
          onSubmit={onSubmit as unknown as FormEventHandler<HTMLDivElement>}
          className="paper-grain dog-ear relative rounded-r-2xl rounded-l-md border border-card-border bg-sheet p-7 pl-10 shadow-paper md:p-10 md:pl-14"
        >
          <span className="absolute inset-y-0 left-6 w-px bg-[var(--margin-line)] md:left-9" aria-hidden="true" />
          <p className="mb-8 font-hand text-3xl text-fg">Dear {profile.name},</p>
          <div className="space-y-7">
            <div>
              <label htmlFor="name" className={labelCls}>
                my name is
              </label>
              <input id="name" name="name" type="text" required autoComplete="name" placeholder="Your name" className={inputCls} />
            </div>
            <div>
              <label htmlFor="email" className={labelCls}>
                you can reach me at
              </label>
              <input id="email" name="email" type="email" required autoComplete="email" placeholder="you@example.com" className={inputCls} />
            </div>
            <div>
              <label htmlFor="message" className={labelCls}>
                and I'd like to talk about
              </label>
              <textarea
                id="message"
                name="message"
                required
                rows={5}
                placeholder="Tell me about your project or opportunity..."
                className="lined mt-2 w-full resize-none border-0 bg-transparent text-[15px] leading-10 text-fg outline-none placeholder:text-faint [--line:2.5rem]"
              />
            </div>
            <button
              type="submit"
              disabled={status === 'sending'}
              className="flex w-full items-center justify-center gap-2 rounded-full bg-royal px-6 py-3.5 text-sm font-semibold text-paper transition-all hover:-translate-y-0.5 hover:bg-navy disabled:opacity-70 dark:bg-sky dark:hover:bg-royal"
            >
              {status === 'sent' ? <CheckCircle2 size={16} /> : <Send size={16} />}
              {status === 'sending' ? 'Sending…' : status === 'sent' ? 'Message ready — thank you!' : 'Send Message'}
            </button>
            <p role="status" className="min-h-4 text-center text-xs text-faint">
              {status === 'error' && 'Something went wrong. Please email me directly instead.'}
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
