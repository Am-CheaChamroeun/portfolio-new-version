/**
 * ─────────────────────────────────────────────────────────────
 *  ALL PERSONAL CONTENT LIVES IN THIS FILE.
 *  Edit the values below — no component changes needed.
 *  Anything in [SQUARE BRACKETS] is a placeholder to replace.
 * ─────────────────────────────────────────────────────────────
 *
 *  Images: put files in /public and reference them by path,
 *  e.g. photo: '/profile.jpg'. Leave a field empty ('') to show
 *  the built-in placeholder instead.
 */
import type { LucideIcon } from 'lucide-react'
import {
  Accessibility,
  Bot,
  Boxes,
  CodeXml,
  Database,
  Gauge,
  GitBranch,
  KeyRound,
  LayoutTemplate,
  Network,
  PanelsTopLeft,
  Server,
  Sparkles,
  Wrench,
} from 'lucide-react'
import type { TechKey } from '../lib/tech'

/* ───────────── Identity ───────────── */

export const profile = {
  name: 'Roeun', // [YOUR FULL NAME]
  initials: 'R',
  /** Shown in the logo as `${handle}${handleSuffix}` → "roeun.dev" */
  handle: 'roeun',
  handleSuffix: '.dev',
  role: 'Frontend Developer',
  /** Short handwritten line on the journal page */
  badgeRole: 'Frontend · Full-Stack',
  /** Hero sub-heading */
  tagline:
    'Frontend developer building fast, accessible web apps with React, TypeScript and Next.js — and growing into the backend.',
  /** Hero headline: "From Sketch to Software." (`from` gets circled, `to` underlined in ink) */
  headline: { lead: 'From', from: 'Sketch', to: 'Software' },
  location: '[YOUR LOCATION]',
  locationFlag: '🌏', // e.g. your country's flag emoji
  /** [lat, lng] for the red marker on the globe — null hides the marker */
  globeMarker: null as [number, number] | null,
  photo: '', // e.g. '/profile.jpg' (portrait, 4:5 works best)
  logo: '', // small round avatar in the header — falls back to `photo`, then initials
  cvUrl: '/cv.pdf', // drop your CV at public/cv.pdf
  /** Entry number printed on the journal page */
  badgeId: 'RN · 2026 · 001',
  missionCode: 'RN-2026', // entry code in the hero's page header
  /** "Currently writing" in the status bar under the hero — your current goal */
  flightPlan: '[YOUR CURRENT GOAL]',
  availability: "I'm currently open to new opportunities. Whether you have a project in mind or just want to connect — my inbox is always open.",
  footerBlurb: 'Frontend developer building fast, reliable web experiences.',
}

export const socials = {
  email: '[YOUR EMAIL]',
  github: { url: 'https://github.com/[YOUR GITHUB]', label: '@[YOUR GITHUB]' },
  linkedin: { url: 'https://www.linkedin.com/in/[YOUR LINKEDIN]', label: '/in/[YOUR LINKEDIN]' },
  telegram: { url: 'https://t.me/[YOUR TELEGRAM]', label: '@[YOUR TELEGRAM]' },
}

/**
 * Optional: a form endpoint (e.g. Formspree) that accepts POSTed JSON.
 * Leave empty to have the contact form open the visitor's email app instead.
 */
export const contactFormEndpoint = ''

/* ───────────── Navigation ───────────── */

export const navLinks = [
  { label: 'About', href: '#about' },
  { label: 'Education', href: '#education' },
  { label: 'Skills', href: '#skills' },
  { label: 'Projects', href: '#projects' },
  { label: 'Services', href: '#services' },
  { label: 'Contact', href: '#contact' },
]

/* ───────────── Hero decorations ───────────── */

export const preloader = {
  role: 'Frontend Developer • Full-Stack Learner',
  chips: ['React', 'TypeScript', 'Next.js', 'NestJS', 'Vite'],
}

/** Lines drafted on the hero blueprint sheet, on a loop */
export const terminalLines: { cmd: string; out?: string; tone?: 'success' | 'info' }[] = [
  { cmd: '$ npm run deploy' },
  { cmd: 'vite build --mode production', out: '✓ built in 1.84s', tone: 'success' },
  { cmd: 'vercel deploy --prod', out: '✓ Ready · Production', tone: 'success' },
  { cmd: 'curl /api/health', out: '200 OK · {"status":"live"}', tone: 'info' },
]

export const heroTelemetry = {
  region: 'EARTH-1',
  status: 'DEPLOYED',
  deploys: 128,
  uptime: '99.98%',
  payload: '1 Engineer',
}

/* ───────────── About ───────────── */

export const about = {
  paragraphs: [
    "I'm a frontend developer with around three years of experience building web applications in React, TypeScript and Next.js. I care about clean component architecture, accessible interfaces and the small details that make a product feel fast.",
    'Lately I have been growing on the backend side — building APIs with NestJS, exploring role-based access control, and learning Spring Boot. I also enjoy headless setups like WordPress + Next.js with REST and GraphQL.',
    '[ADD A LINE ABOUT WHAT YOU ARE LOOKING FOR OR WHAT DRIVES YOU.]',
  ],
  chips: ['Frontend Developer', 'React & Next.js', 'TypeScript', 'Lifelong Learner'],
  /** Logos in the page-flipping "My toolbox" sketchbook (inner list first, then outer) */
  orbitInner: ['react', 'nextjs', 'typescript', 'nestjs', 'vite'] as TechKey[],
  orbitOuter: ['springboot', 'graphql', 'wordpress', 'git'] as TechKey[],
  features: [
    { icon: CodeXml, label: 'Clean Architecture' },
    { icon: GitBranch, label: 'Type-safe by Default' },
    { icon: Gauge, label: 'Performance Minded' },
    { icon: Sparkles, label: 'Quality Delivery' },
  ] as { icon: LucideIcon; label: string }[],
}

/* ───────────── Education ───────────── */

export type EducationItem = {
  school: string
  period: string
  details: string[]
  current?: boolean
  url?: string
  logo?: string // e.g. '/education/university.png'
}

export const education: EducationItem[] = [
  {
    school: '[UNIVERSITY / SCHOOL NAME]',
    period: '[YEAR] — [YEAR]',
    details: ["[DEGREE OR PROGRAM, e.g. Bachelor's Degree in Computer Science]"],
    current: true,
    url: '',
  },
  {
    school: '[COURSE, BOOTCAMP OR ACADEMY]',
    period: '[YEAR] — [YEAR]',
    details: ['[WHAT YOU STUDIED]', '[OPTIONAL SECOND LINE]'],
    url: '',
  },
  {
    school: '[HIGH SCHOOL]',
    period: '[YEAR] — [YEAR]',
    details: ['[DIPLOMA / EXAM]'],
  },
]

/* ───────────── Skills ───────────── */

/** level: 1–12 segments. 11+ = expert, 9–10 = advanced, 7–8 = proficient, below = learning */
export type Skill = { name: string; icon: TechKey; level: number }
export type SkillGroup = { key: string; label: string; icon: LucideIcon; skills: Skill[] }

// TODO: adjust levels to how you'd rate yourself.
export const skillGroups: SkillGroup[] = [
  {
    key: 'frontend',
    label: 'Frontend',
    icon: PanelsTopLeft,
    skills: [
      { name: 'React', icon: 'react', level: 11 },
      { name: 'TypeScript', icon: 'typescript', level: 10 },
      { name: 'Next.js', icon: 'nextjs', level: 10 },
      { name: 'Vite', icon: 'vite', level: 9 },
      { name: 'JavaScript', icon: 'javascript', level: 11 },
    ],
  },
  {
    key: 'backend',
    label: 'Backend',
    icon: Server,
    skills: [
      { name: 'NestJS', icon: 'nestjs', level: 8 },
      { name: 'Node.js', icon: 'nodejs', level: 8 },
      { name: 'Spring Boot', icon: 'springboot', level: 5 },
    ],
  },
  {
    key: 'data',
    label: 'APIs & CMS',
    icon: Database,
    skills: [
      { name: 'GraphQL', icon: 'graphql', level: 7 },
      { name: 'Headless WordPress', icon: 'wordpress', level: 7 },
      { name: 'PostgreSQL', icon: 'postgresql', level: 6 },
    ],
  },
  {
    key: 'tools',
    label: 'Tools',
    icon: Wrench,
    skills: [
      { name: 'Git', icon: 'git', level: 10 },
      { name: 'Claude Code', icon: 'claude', level: 9 },
      { name: 'Figma', icon: 'figma', level: 7 },
    ],
  },
]

/* ───────────── Certifications ───────────── */

export type Certificate = {
  title: string
  issuer: string
  issuerFull?: string
  date: string
  image?: string // e.g. '/certs/my-certificate.jpg' (landscape)
}

export const certificates: Certificate[] = [
  { title: '[CERTIFICATE TITLE]', issuer: '[ISSUER]', issuerFull: '[ISSUER FULL NAME]', date: '[MON YEAR]' },
  { title: '[CERTIFICATE TITLE]', issuer: '[ISSUER]', issuerFull: '[ISSUER FULL NAME]', date: '[MON YEAR]' },
]

/* ───────────── Projects ───────────── */

export type Project = {
  name: string
  slug: string
  tagline?: string
  description: string
  highlights: string[]
  tech: string[]
  /** Accent colour for the preview window (hex) */
  accent: string
  liveUrl?: string
  repoUrl?: string
  image?: string // screenshot or logo in /public
  imageFit?: 'cover' | 'contain'
}

export const featuredProject: Project = {
  name: '[FEATURED PROJECT]',
  slug: 'featured-project',
  tagline: '[ONE-LINE PITCH OF THE PROJECT]',
  description: '[TWO OR THREE SENTENCES ABOUT WHAT IT DOES, WHO IT IS FOR, AND YOUR ROLE.]',
  highlights: ['[KEY FEATURE]', '[KEY FEATURE]', '[KEY FEATURE]'],
  tech: ['Next.js', 'TypeScript', 'NestJS', 'PostgreSQL'],
  accent: '#f97316',
  liveUrl: '',
  repoUrl: '',
}

export const projects: Project[] = [
  {
    name: '[PROJECT NAME]',
    slug: 'project-one',
    description: '[SHORT DESCRIPTION]',
    highlights: ['[FEATURE]', '[FEATURE]', '[FEATURE]'],
    tech: ['React', 'TypeScript', 'Vite'],
    accent: '#2563eb',
    repoUrl: '',
  },
  {
    name: '[PROJECT NAME]',
    slug: 'project-two',
    description: '[SHORT DESCRIPTION]',
    highlights: ['[FEATURE]', '[FEATURE]', '[FEATURE]'],
    tech: ['Next.js', 'WordPress', 'GraphQL'],
    accent: '#f59e0b',
    repoUrl: '',
  },
  {
    name: '[PROJECT NAME]',
    slug: 'project-three',
    description: '[SHORT DESCRIPTION]',
    highlights: ['[FEATURE]', '[FEATURE]', '[FEATURE]'],
    tech: ['NestJS', 'PostgreSQL', 'Docker'],
    accent: '#10b981',
    repoUrl: '',
  },
]

/* ───────────── Services ───────────── */

export const services: { title: string; description: string; stack: string; icon: LucideIcon }[] = [
  {
    title: 'Frontend Development',
    description: 'Responsive, accessible interfaces built from reusable, type-safe React components.',
    stack: 'React · TypeScript · Vite · Tailwind',
    icon: PanelsTopLeft,
  },
  {
    title: 'Next.js Applications',
    description: 'Server-rendered and statically generated apps with the App Router, ISR and clean data fetching.',
    stack: 'Next.js · App Router · ISR · Vercel',
    icon: LayoutTemplate,
  },
  {
    title: 'Headless CMS',
    description: 'Editors keep their familiar CMS while the frontend stays fast and fully custom.',
    stack: 'WordPress · REST · GraphQL',
    icon: Boxes,
  },
  {
    title: 'API Development',
    description: 'Structured, documented REST APIs with validation, modules and sensible error handling.',
    stack: 'NestJS · Node.js · Spring Boot',
    icon: Server,
  },
  {
    title: 'Auth & Access Control',
    description: 'Role- and permission-based access with guards and decorators — locked down by default.',
    stack: 'RBAC · Guards · JWT',
    icon: KeyRound,
  },
  {
    title: 'Performance Tuning',
    description: 'Faster loads through code-splitting, image optimisation and fewer unnecessary re-renders.',
    stack: 'Lighthouse · Web Vitals · Profiler',
    icon: Gauge,
  },
  {
    title: 'Accessibility',
    description: 'Semantic markup, keyboard support and readable contrast so everyone can use the product.',
    stack: 'WCAG · ARIA · Semantic HTML',
    icon: Accessibility,
  },
  {
    title: 'API Integration',
    description: 'Connecting frontends to third-party services and backends with typed, resilient clients.',
    stack: 'REST · GraphQL · Webhooks',
    icon: Network,
  },
  {
    title: 'AI-Assisted Workflow',
    description: 'Using AI coding tools to move faster while keeping code reviewed, tested and maintainable.',
    stack: 'Claude Code · Prompting · Review',
    icon: Bot,
  },
]

/** Highlights the first N service cards (the rest render faded) */
export const highlightedServices = 2

/* ───────────── Stats band ───────────── */

// TODO: replace with your real numbers.
export const stats = [
  { value: 10, suffix: '+', label: 'Projects Completed' },
  { value: 12, suffix: '+', label: 'Technologies Used' },
  { value: 3, suffix: '+', label: 'Years Coding' },
  { value: 1000, suffix: '+', label: 'Hours Coding' },
]

