# Portfolio

Personal portfolio built with **Vite + React + TypeScript + Tailwind CSS v4**, animated with **Motion** and icons from **Lucide** / **simple-icons**.

Concept: **"The Developer's Notebook — From Sketch to Software."** Blue drafting desk, white notebook pages, pencil sketches, blueprints and handwritten notes. Paper (light) is the default theme; Blueprint (dark) is one click away.

## Run it

```bash
npm install
npm run dev       # http://localhost:5173
npm run build     # type-check + production build → dist/
npm run preview   # serve the production build
```

## Make it yours

All personal content lives in **`src/data/portfolio.ts`**. Anything in `[SQUARE BRACKETS]` is a placeholder.

| What | Where |
| --- | --- |
| Name, role, tagline, headline words, ID badge text | `profile` |
| Email, GitHub, LinkedIn, Telegram | `socials` |
| Photo / avatar | put `profile.jpg` in `public/`, set `profile.photo: '/profile.jpg'` |
| CV download | put `cv.pdf` in `public/` (or set `profile.cvUrl: ''` to hide the buttons) |
| Globe marker | `profile.globeMarker: [lat, lng]` |
| Education, skills, certificates, projects, services, stats | their own exports in the same file |
| Contact form | set `contactFormEndpoint` (e.g. Formspree) — otherwise it opens the visitor's email app |

Tech logos come from [simple-icons](https://simpleicons.org). To use a new one, add it to `src/lib/tech.ts`, then reference its key in the data file.

## Structure

```text
src/
├── App.tsx                 page composition
├── data/portfolio.ts       ← all your content
├── sections/               Hero, About, Education, Skills, Certifications,
│   └── hero/               Projects, Services, Stats, Contact (+ journal card,
│                           field notes, blueprint sheet)
├── components/
│   ├── layout/             Header, Footer, Preloader (notebook opening)
│   ├── effects/            Globe, SketchToSoftware, PencilCursor, ScrollPencil,
│   │                       ScrollProgress, BackToTop
│   └── ui/                 Reveal, SectionHeading, InkUnderline, Pencil,
│                           StatusPill, Avatar
├── hooks/                  useTheme, useIsDark, useInterval
├── lib/                    icon helpers, shared easing
└── styles/index.css        palette (paper + blueprint), paper/grid/ruled utilities
```

Fonts: Fraunces (editorial serif), Caveat (handwritten notes), Geist (body), JetBrains Mono (labels).

## Notes

- Paper (light) is the default; the moon/sun button switches to Blueprint (dark) with a circular reveal and remembers the choice.
- Animations respect `prefers-reduced-motion`. The pencil cursor only appears with a mouse.
- `src/App.css`, `src/index.css` and the images in `src/assets/` are leftovers from the Vite starter and are no longer used — safe to delete.
